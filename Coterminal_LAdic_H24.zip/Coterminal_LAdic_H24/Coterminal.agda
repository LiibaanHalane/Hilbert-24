{-# OPTIONS --safe #-}
module Coterminal where
open import Agda.Builtin.Equality

sym : {A : Set} {a b : A} → a ≡ b → b ≡ a
sym refl = refl

trans : {A : Set} {a b c : A} → a ≡ b → b ≡ c → a ≡ c
trans refl q = q

cong : {A B : Set} (f : A → B) {a b : A} → a ≡ b → f a ≡ f b
cong f refl = refl

-- Hom types already restricted to the corresponding structured maps.
reverseUnique : {A B : Set} (dag : A → B) (back : B → A)
  ((b : B) → dag (back b) ≡ b) →
  ((a a' : A) → a ≡ a') → (b b' : B) → b ≡ b'
reverseUnique dag back ret unique b b' =
  trans (sym (ret b)) (trans (cong dag (unique (back b) (back b'))) (ret b'))

-- Complete marked inverse readback transports a proof, not a probability.
readback : {A B : Set} (e : A → B) (d : B → A)
  ((x : A) → d (e x) ≡ x) → (P : A → Set) →
  (x : A) → P (d (e x)) → P x
readback e d ret P x p with ret x
... | refl = p
