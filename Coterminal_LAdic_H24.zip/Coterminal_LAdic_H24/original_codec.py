"""Original Golay and Collatz quotation functions from Null_Cone_H24/check.py.
Extracted verbatim by AST; no old top-level experiment is run.
"""

from itertools import combinations, product

SPECS={'G23':(2,12,23,7,3,[1,1,0,0,0,1,1,1,0,1,0,1]),'G24':(2,12,24,8,3,[1,1,0,0,0,1,1,1,0,1,0,1]),'G11':(3,6,11,5,2,[2,0,1,2,1,1]),'G12':(3,6,12,6,2,[2,0,1,2,1,1])}

def encode(m,s):
    p,k,n,d,t,g=s; short=k+len(g)-1
    assert len(m)==k and all(0<=x<p for x in m)
    out=[0]*short
    for i,x in enumerate(m):
        for j,y in enumerate(g):out[i+j]=(out[i+j]+x*y)%p
    if n>short:out.append(-sum(out)%p)
    return tuple(out)

def division(w,s):
    p,k,n,d,t,g=s; short=k+len(g)-1
    a=list(w[:short]); m=[0]*k
    for i in range(k-1,-1,-1):
        m[i]=a[i+len(g)-1]%p
        for j,y in enumerate(g):a[i+j]=(a[i+j]-m[i]*y)%p
    return tuple(m),tuple(a[:len(g)-1])

def syndrome(w,s):
    p,k,n,d,t,g=s; _,r=division(w,s)
    return r+((sum(w)%p,) if n==k+len(g) else ())

def errors(n,p,t):
    for a in range(t+1):
        for coords in combinations(range(n),a):
            for vals in product(range(1,p),repeat=a):
                e=[0]*n
                for i,v in zip(coords,vals):e[i]=v
                yield tuple(e)

def table(s):
    p,k,n,d,t,g=s; tab={}
    for e in errors(n,p,t):
        z=syndrome(e,s);assert z not in tab;tab[z]=e
    return tab

def correct(w,s,tab):
    p,k,n,d,t,g=s
    if len(w)!=n or any(not isinstance(x,int) or not 0<=x<p for x in w):raise ValueError('alphabet/length')
    e=tab.get(syndrome(w,s))
    if e is None: return None
    cw=tuple((x-y)%p for x,y in zip(w,e));m,r=division(cw,s)
    assert not any(r) and encode(m,s)==cw
    return m,e

def base_digits(n,p):
    out=[]
    while n:n,r=divmod(n,p);out.append(r)
    return out or [0]

def blocks(n,s):
    p,k,*_=s; a=base_digits(n,p)
    return [encode(tuple((a+[0]*k)[i:i+k]),s) for i in range(0,len(a),k)]

def readblocks(words,s,tab):
    p,k,*_=s; value=0
    for w in reversed(words):
        result=correct(w,s,tab)
        if result is None:raise ValueError('uncorrectable within guaranteed radius')
        m,_=result
        value=value*p**k+sum(x*p**j for j,x in enumerate(m))
    if len(words)!=len(blocks(value,s)):raise ValueError('noncanonical padding')
    return value

def gamma(n):
    assert n>=1; b=bin(n)[2:];return '0'*(len(b)-1)+b

def field(s):
    b=s.encode(); return gamma(len(b)+1)+''.join(f'{x:08b}' for x in b)

def quote(record):
    vals=['H24-NULL-v1',record['id'],record['source'],record['hypotheses'],record['conclusion'],str(len(record['parents'])),*record['parents'],record['proof_source']]
    return ''.join(field(v) for v in vals)

def anchor(w):
    k=len(w); mod=1<<k; a=0
    # Exact affine inverse of the chronological parity word.
    for i,b in enumerate(w):a=3*a+(int(b)<<i)
    return (-a*pow(pow(3,k,mod),-1,mod))%mod

def decode_address(g):
    if not isinstance(g,int) or g<0: raise ValueError('invalid Godel address')
    k=(g+1).bit_length()-1; a=g+1-(1<<k)
    w=[]
    for _ in range(k):
        b=a%2; w.append(str(b)); a=(3*a+b)//2
    return ''.join(w)

def unquote(w):
    i=0; vals=[]
    while i<len(w):
        z=0
        while i<len(w) and w[i]=='0': z+=1; i+=1
        if i+z>=len(w): raise ValueError('incomplete gamma code')
        length=int(w[i:i+z+1],2)-1; i+=z+1
        end=i+8*length
        if end>len(w): raise ValueError('incomplete quotation field')
        vals.append(bytes(int(w[j:j+8],2) for j in range(i,end,8)).decode('utf-8'))
        i=end
    if len(vals)<7 or vals[0]!='H24-NULL-v1':raise ValueError('bad grammar')
    n=int(vals[5]);
    if n<0 or len(vals)!=7+n:raise ValueError('incorrect parent count')
    return {'id':vals[1],'source':vals[2],'hypotheses':vals[3],
            'conclusion':vals[4],'parents':vals[6:6+n],'proof_source':vals[6+n]}
