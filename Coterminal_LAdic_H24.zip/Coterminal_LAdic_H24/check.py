"""Exact finite tests of the written proof, not a quantum speed or kernel benchmark."""
import itertools, json, math, random, hashlib
from fractions import Fraction
from pathlib import Path
from original_prefix import Prefix, EMPTY, summary
from original_codec import SPECS, table, quote, unquote, anchor, decode_address, blocks, readblocks
P=Path(__file__).resolve().parent
rng=random.Random(24)
checks={}

def M(n): return 3**n-2**n

def lift(b): return 6*((b+7)//6)

def marked_integer(r,D,N):
    assert N>2*D
    r%=N
    z=r if r<=D else r-N
    if not -D<=z<=D: raise ValueError('outside retained interval')
    return z

def perm(g,x):
    kind,*s=g
    if kind=='X': return x^(1<<s[0])
    if kind=='T': return x^(1<<s[2]) if ((x>>s[0])&1) and ((x>>s[1])&1) else x
    if kind=='F':
        return x^((1<<s[1])|(1<<s[2])) if ((x>>s[0])&1) and ((x>>s[1])&1)!=((x>>s[2])&1) else x
    raise ValueError(g)

def evaluate(gates,q,initial,mod=None):
    v=list(initial)
    for g in gates:
        if g[0]=='H':
            j=g[1]; w=v.copy()
            for x in range(1<<q):
                if x>>j&1: continue
                y=x|(1<<j); w[x],w[y]=v[x]+v[y],v[x]-v[y]
            v=w
        else:
            w=[0]*len(v)
            for x,a in enumerate(v):w[perm(g,x)]=a
            v=w
        if mod:v=[x%mod for x in v]
    return v

def path_sum(gates,q):
    # Independent literal signed path expansion only for small test instances.
    paths=[(0,1)]
    for g in gates:
        if g[0]=='H':
            j=g[1]; paths=[(x&~(1<<j)|(y<<j),s*(-1 if ((x>>j)&1)*y else 1)) for x,s in paths for y in (0,1)]
        else:paths=[(perm(g,x),s) for x,s in paths]
    v=[0]*(1<<q)
    for x,s in paths:v[x]+=s
    return v

for _ in range(160):
    q=rng.randrange(3,6); gates=[]
    for i in range(rng.randrange(1,14)):
        k=rng.choice(['H','H','X','T','F']); gates.append((k,*rng.sample(range(q),1 if k in ('H','X') else 3)))
    b=sum(g[0]=='H' for g in gates); D=1<<b; h=lift(b); N=M(h)
    assert h>=b+2 and h%6==0 and N>2*D
    v=evaluate(gates,q,[1]+[0]*((1<<q)-1)); assert v==path_sum(gates,q)
    S=sum(v[x]**2 for x in range(len(v)) if x&1); R=sum(v[x]**2 for x in range(len(v)) if not x&1)
    assert S+R==D
    x=[rng.randrange(-7,8) for _ in v];y=evaluate(gates,q,x);assert sum(a*a for a in y)==D*sum(a*a for a in x)
    m=2*S-D; w=evaluate(gates,q,[1]+[0]*(len(v)-1),N)
    assert marked_integer((2*sum(w[x]**2 for x in range(len(w)) if x&1)-D)%N,D,N)==m
    assert (3*S>=2*D)==(3*m>=D) and (3*S<=D)==(3*m<=-D)
    a=3*pow(2,-1,N)%N; assert pow(a,h,N)==1 and all(pow(a,j,N)!=1 for j in range(1,h))
    # Original cyclic relation x_i=z x_(i-1)+b_i; its quotient numerator.
    z=2*pow(3,-1,N)%N; u=[rng.randrange(N) for _ in range(h)];B=[(u[i]-z*u[i-1])%N for i in range(h)]
    assert (B[0]+sum(pow(z,h-j,N)*B[j] for j in range(1,h)))%N==0
checks['signed_circuit_path_gram_and_obstruction']=160

for b in range(1024):
    D=1<<b; h=lift(b); assert h>=b+2 and M(h)>2*D
checks['aperture_size_checks']=1024

# Gray derivative with retained low endpoint; high endpoint also determines inverse.
for n in range(1,11):
    for x in range(1<<n):
        bits=[(x>>i)&1 for i in range(n)];g=[bits[i]^bits[i+1] for i in range(n-1)]
        out=[bits[0]]
        for a in g:out.append(out[-1]^a)
        assert out==bits
        assert (sum(g[i]<<i for i in range(n-1)) | (bits[-1]<<(n-1)))==x^(x>>1)
        for k in range(1,n+1):assert out[:k]==bits[:k] and g[:k-1]==[bits[j]^bits[j+1] for j in range(k-1)]
checks['gray_seam_roundtrips']=sum(1<<n for n in range(1,11))

# Actual archived prefix law; depth 64 uses 65 summaries, not expansion.
levels=[Prefix(1,-1,-1)]
for _ in range(64):
    q=Prefix(1,2,0)
    for _ in range(3):q=q.then(levels[-1])
    levels.append(q)
assert all(p==Prefix((3**(k+1)-1)//2,-1,-1) for k,p in enumerate(levels))
def first_hit(k,b):
    if b+levels[k].low>=0:return None
    if k==0:return 1
    offset=1;b+=2
    for _ in range(3):
        j=first_hit(k-1,b)
        if j is not None:return offset+j
        offset+=levels[k-1].L;b+=levels[k-1].drift
    raise AssertionError('unreachable')
assert first_hit(64,0)==levels[64].L
checks['shared_first_failure_depth']=64
checks['shared_first_failure_index']=str(levels[64].L)
# Actual seed-8 recurrence at a declared finite cut only.
a,b=8,0; word=[]; first=None
for k in range(4096):
    e=a%2;word.append(str(e));a=(3*a-e)//2;b+=2-3*e
    if b<0 and first is None:first=k+1
assert summary(''.join(word)).drift==b
chunks=[summary(''.join(word[i:i+128])) for i in range(0,len(word),128)];total=EMPTY
for x in chunks:total=total.then(x)
assert total==summary(''.join(word));assert (first is None)==(total.low>=0)
checks['seed8_finite_prefix']={'length':len(word),'minimum':total.low,'balance':b,'first_failure_within_cut':first,'scope':'finite prefix only'}

# Finite first-hit series: v2 at z=2/3; all earlier apertures are zero.
for t in range(65):
    for k in range(1,66):
        value=pow(2,t,1<<k)*pow(pow(3,t,1<<k),-1,1<<k)%(1<<k)
        assert (value==0)==(k<=t)
checks['first_hit_residue_checks']=65*65

# Exact majority improvement, the original 2/3 normalized witness.
p=Fraction(2,3); r=1-p
error=lambda j:sum(math.comb(2*j+1,i)*p**i*r**(2*j+1-i) for i in range(j+1))
for j in range(64):assert error(j)-error(j+1)==math.comb(2*j+1,j)*(2*p-1)*(p*r)**(j+1)
checks['majority_decrement_identities']=64

# Protected full written proof ports, using existing source quotation convention.
ports=[('CT-01','dagger duality','dagger-preserving F; supplied terminality','initial algebra; unitary subcategory coterminality',[]),('CT-02','integer quantum Gram','Hadamard and reversible basis gates','integral Gram and exact signed margin',['CT-01']),('CT-03','L-adic BQP obstruction','marked gate term and promise','PromiseBQP-complete marked obstruction sign',['CT-02']),('CT-04','stopping and Gray chart','original deterministic transition; imported Skelet17 checkpoint theorem','first-hit valuation and finite/infinite Gray return',['CT-01']),('CT-05','amortization and arithmetic return','shared prefix grammar; given relative grade','first failure fold and majority calibration',['CT-03','CT-04'])]
src=(P/'paper.tex').read_text();tabs={nm:table(sp) for nm,sp in SPECS.items()};records=[]
for ident,name,h,c,parents in ports:
    body=src.split('%% BEGIN '+ident+'\n',1)[1].split('%% END '+ident,1)[0].rstrip()
    record=dict(id=ident,source='paper.tex:'+name,hypotheses=h,conclusion=c,parents=parents,proof_source=body)
    w=quote(record);a=anchor(w);g=(1<<len(w))-1+a
    assert unquote(decode_address(g))==record
    enc={}
    for nm,sp in SPECS.items():
        bs=blocks(g,sp); ret=readblocks(bs,sp,tabs[nm]);assert ret==g and unquote(decode_address(ret))==record
        enc[nm]=[''.join(map(str,x)) for x in bs]
    records.append(dict(**record,depth=len(w),residue_hex=hex(a),godel_hex=hex(g),four_golay=enc,quote_sha256=hashlib.sha256(w.encode()).hexdigest()))
(P/'canonical_codes.json').write_text(json.dumps(records,indent=2)+'\n'); checks['full_Golay_roundtrips']=4*len(records)
(P/'receipt.json').write_text(json.dumps({'checks':checks,'scope':'Finite exact arithmetic checks and full theorem quotation readbacks; no new formal kernel replay, quantum hardware or full Busy Beaver decision.'},indent=2)+'\n')
print((P/'receipt.json').read_text())
