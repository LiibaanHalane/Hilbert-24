import Mathlib

/- Elementary consequence ports of CT-01--CT-05. No axioms about halting. -/
namespace CoterminalH24

theorem positive_margin (s d : ℤ) : 3*s ≥ 2*d ↔ 3*(2*s-d) ≥ d := by omega

theorem opposing_margin (s d : ℤ) : 3*s ≤ d ↔ 3*(2*s-d) ≤ -d := by omega

-- The residue equality is witnessed by its integer multiple of the modulus.
theorem marked_lift_unique (x y d n k : ℤ) (hn : 2*d < n)
    (hx : -d ≤ x ∧ x ≤ d) (hy : -d ≤ y ∧ y ≤ d)
    (hxy : x-y = k*n) : x = y := by
  rcases lt_trichotomy k 0 with hk | hk | hk
  · have hkn : k ≤ -1 := by omega
    have hp : 0 ≤ n := by omega
    have hz : k*n ≤ (-1)*n := mul_le_mul_of_nonneg_right hkn hp
    omega
  · rw [hk, zero_mul] at hxy
    omega
  · have hkn : 1 ≤ k := by omega
    have hp : 0 ≤ n := by omega
    have hz : 1*n ≤ k*n := mul_le_mul_of_nonneg_right hkn hp
    omega

-- Dagger reverses the unique morphism on the stipulated structured homs.
theorem reverse_unique {A B : Type} (dag : A → B) (back : B → A)
    (ret : ∀ b, dag (back b) = b) (terminal : ∀ a a' : A, a = a')
    (b b' : B) : b = b' := by
  calc
    b = dag (back b) := (ret b).symm
    _ = dag (back b') := congrArg dag (terminal _ _)
    _ = b' := ret b'

-- Exact local cancellation; no choice of a global constructor is presumed.
theorem prefix_telescope (a b c : ℤ) : (b-a)+(c-b) = c-a := by ring
end CoterminalH24
