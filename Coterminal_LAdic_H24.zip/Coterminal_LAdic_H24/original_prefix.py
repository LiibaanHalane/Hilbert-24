"""Unchanged prefix monoid from Braided_Gauge_H24/wire.py (extracted)."""
from dataclasses import dataclass
@dataclass(frozen=True)
class Prefix:
    L:int; drift:int; low:int
    def then(self,b): return Prefix(self.L+b.L,self.drift+b.drift,min(self.low,self.drift+b.low))
EMPTY=Prefix(0,0,0)
def summary(w):
    a=EMPTY
    for b in w:a=a.then(Prefix(1,2 if b=='0' else -1,0 if b=='0' else -1))
    return a
