#!/usr/bin/env python3
"""Exact finite certificate checks and a free noncommutative polynomial proof checker.
This checks the declared algebraic consequences, not unbounded operator domains.
Canonical marks encode the typed theorem-constructor DAG, not a proof-search oracle.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import product, combinations
import json, hashlib, pathlib, math, sys, re
sys.set_int_max_str_digits(0)
from dataclasses import dataclass
P=pathlib.Path(__file__).parent
if not __debug__: raise RuntimeError("Run the exact checker without -O")
# A free associative polynomial normalizer. An ideal certificate proves f=0
# from named equations h=0 via f = sum c * left * h * right.
@dataclass(frozen=True)
class Poly:
    d: dict
    def __add__(self,o):
        o=poly(o); d=self.d.copy()
        for k,v in o.d.items():d[k]=d.get(k,F(0))+v
        return Poly({k:v for k,v in d.items() if v})
    __radd__=__add__
    def __neg__(self):return Poly({k:-v for k,v in self.d.items()})
    def __sub__(self,o):return self+-poly(o)
    def __rsub__(self,o):return poly(o)+-self
    def __mul__(self,o):
        o=poly(o); d={}
        for k,v in self.d.items():
            for l,w in o.d.items():d[k+l]=d.get(k+l,F(0))+v*w
        return Poly({k:v for k,v in d.items() if v})
    __rmul__=__mul__
    def __pow__(self,n):
        a=poly(1)
        for _ in range(n):a=a*self
        return a

def poly(x):
    if isinstance(x,Poly):return x
    if isinstance(x,str):return Poly({(x,):F(1)})
    return Poly({():F(x)} if x else {})
proof_checks=[]
def identity(name,l,r):
    assert poly(l)-r==poly(0),name
    proof_checks.append({'theorem':name,'method':'free associative normal form','status':'proved algebraic identity'})
def ideal(name,target,relations,certificate):
    rhs=poly(0)
    for coef,left,key,right in certificate:
        rhs+=poly(coef)*poly(left)*relations[key]*poly(right)
    assert poly(target)==rhs,name
    proof_checks.append({'theorem':name,'method':'explicit two-sided ideal certificate','premises':list(relations),'status':'proved consequence'})
# K/u0 = a^{-1/2} V* exp(Xi) V a^{-1/2}; h denotes a^{-1/2}.
# d is the angular square factor, s is its adjoint times itself; C=e^Xi.
# Angle is separately derived via weighted angular expansion below.
H,V,Vd,C,A=map(poly,['h','V','V*','C','a'])
identity('radial_split',H*Vd*C*V*H,H*Vd*(C-1)*V*H+H*Vd*V*H)
ideal('radial_split_isometry',H*Vd*C*V*H-H*Vd*(C-1)*V*H-H*H,
      {'V*V=1':Vd*V-1},[(1,H,'V*V=1',H)])
# At a finite weighted angular partition, no commutation of rho_i required.
weights=[F(1,2),F(1,3),F(1,6)]; rs=list(map(poly,['rho0','rho1','rho2']))
a=sum(w*r for w,r in zip(weights,rs)); raw=sum(w*r*r for w,r in zip(weights,rs))
identity('angular_variance',sum(w*(r-a)*(r-a) for w,r in zip(weights,rs)),raw-a*a)
# Fractional normalizing factor h and commuting scalar functions can be
# represented without radical arithmetic: (1+a)a(a^-1-1)=1-a^2.
# Prove modulo a*aInv=1; multiplication need not be commutative elsewhere.
Ai=poly('aInv')
# expanded (Ai-1)*a*(1+a)-(1-a*a)=(Ai*a-1)*(1+a)
ideal('angular_inverse_residual',(Ai-1)*A*(1+A)-(1-A*A),{'aInv*a=1':Ai*A-1},[(1,1,'aInv*a=1',1+A)])
T,q=map(poly,['T','q'])
# q real scalar, use actual 2/3 for the polynomial identity.
identity('three_moment',3*(1-T)*(F(2,3)-T),2-5*T+3*T*T)
# exact transfer under an intertwiner T' U = U T
Tp,U=map(poly,['Tp','U']); rel={'TpU=UT':Tp*U-U*T}
ideal('sensor_intertwines',(2-5*Tp+3*Tp*Tp)*U-U*(2-5*T+3*T*T),rel,
      [(-5,1,'TpU=UT',1),(3,Tp,'TpU=UT',1),(3,1,'TpU=UT',T)])
# composition of Gram defects, free *-algebra variables.
B,Bd,Ad=map(poly,['B','B*','A*']); identity('composite_defect',1-Ad*Bd*B*A,(1-Ad*A)+Ad*(1-Bd*B)*A)
# weighted spectral margin: B_q = B_qprime + (q-qprime)(I-T).
identity('weighted_margin', (1-T)*(F(2,3)-T),(1-T)*(F(1,2)-T)+F(1,6)*(1-T))
# Compression with the original isometric inclusion. Qc is a central scalar
# represented here by an exact rational; general q is proved in the paper.
J,Jd=map(poly,['J','J*']); Kc=Jd*T*J; Qc=F(2,3)
leak=Jd*T*(1-J*Jd)*T*J
compression=Jd*(1-T)*(Qc-T)*J-((1-Kc)*(Qc-Kc)+leak)
ideal('sensor_compression',compression,{'J*J=1':Jd*J-1},[(Qc,1,'J*J=1',1)])
# Arbitrary central spectral parameters, not only a numerical specialization.
Qp=poly('qprime')
ideal('central_weighted_margin',(1-T)*(q-T)-(1-T)*(Qp-T)-(q-Qp)*(1-T),
      {'qT=Tq':q*T-T*q,'qpT=Tqp':Qp*T-T*Qp},
      [(1,1,'qT=Tq',1),(-1,1,'qpT=Tqp',1)])
# resolvent threshold: (L/(L+l)) = beta/2 for l=L(2/beta-1).
for beta in [F(1,2),F(1,7),F(99,100)]:
    L=F(3,5); ell=L*(2/beta-1); assert L/(L+ell)==beta/2
# Golay code construction, fixed small finite alphabets. No search over proofs.
SPECS={'G23':(2,12,23,7,3,[1,1,0,0,0,1,1,1,0,1,0,1]),'G24':(2,12,24,8,3,[1,1,0,0,0,1,1,1,0,1,0,1]),'G11':(3,6,11,5,2,[2,0,1,2,1,1]),'G12':(3,6,12,6,2,[2,0,1,2,1,1])}
def encode(m,s):
    p,k,n,d,t,g=s; short=k+len(g)-1
    assert len(m)==k and all(0<=x<p for x in m)
    out=[0]*short
    for i,x in enumerate(m):
        for j,y in enumerate(g):out[i+j]=(out[i+j]+x*y)%p
    if n>short:out.append(-sum(out)%p)
    return tuple(out)
def division(w,s):
    p,k,n,d,t,g=s; short=k+len(g)-1
    a=list(w[:short]); m=[0]*k
    for i in range(k-1,-1,-1):
        m[i]=a[i+len(g)-1]%p
        for j,y in enumerate(g):a[i+j]=(a[i+j]-m[i]*y)%p
    return tuple(m),tuple(a[:len(g)-1])
def syndrome(w,s):
    p,k,n,d,t,g=s; _,r=division(w,s)
    return r+((sum(w)%p,) if n==k+len(g) else ())
def errors(n,p,t):
    for a in range(t+1):
        for coords in combinations(range(n),a):
            for vals in product(range(1,p),repeat=a):
                e=[0]*n
                for i,v in zip(coords,vals):e[i]=v
                yield tuple(e)
def table(s):
    p,k,n,d,t,g=s; tab={}
    for e in errors(n,p,t):
        z=syndrome(e,s);assert z not in tab;tab[z]=e
    return tab
def correct(w,s,tab):
    p,k,n,d,t,g=s
    if len(w)!=n or any(not isinstance(x,int) or not 0<=x<p for x in w):raise ValueError('alphabet/length')
    e=tab.get(syndrome(w,s))
    if e is None: return None
    cw=tuple((x-y)%p for x,y in zip(w,e));m,r=division(cw,s)
    assert not any(r) and encode(m,s)==cw
    return m,e
def base_digits(n,p):
    out=[]
    while n:n,r=divmod(n,p);out.append(r)
    return out or [0]
def blocks(n,s):
    p,k,*_=s; a=base_digits(n,p)
    return [encode(tuple((a+[0]*k)[i:i+k]),s) for i in range(0,len(a),k)]
def readblocks(words,s,tab):
    p,k,*_=s; value=0
    for w in reversed(words):
        result=correct(w,s,tab)
        if result is None:raise ValueError('uncorrectable within guaranteed radius')
        m,_=result
        value=value*p**k+sum(x*p**j for j,x in enumerate(m))
    if len(words)!=len(blocks(value,s)):raise ValueError('noncanonical padding')
    return value
stats={};tabs={}
for name,s in SPECS.items():
    p,k,n,d,t,g=s; enum=Counter()
    for m in product(range(p),repeat=k):
        w=encode(m,s); mm,rem=division(w,s); assert mm==m and not any(rem)
        enum[sum(x!=0 for x in w)]+=1
    assert min(i for i in enum if i)==d
    tab=table(s);tabs[name]=tab
    assert len(tab)==sum(math.comb(n,j)*(p-1)**j for j in range(t+1))
    if name in ('G23','G11'):assert len(tab)==p**(n-k)
    # Check one message for EVERY correctable error; translation by a codeword preserves syndrome.
    m=tuple((i+1)%p for i in range(k)); w=encode(m,s)
    for e in tab.values():assert correct(tuple((x+y)%p for x,y in zip(w,e)),s,tab)[0]==m
    stats[name]={'parameters':[n,k,d,p],'weight_enumerator':dict(sorted(enum.items())),'correctable_syndromes':len(tab),'message_count':p**k}
# On extended codes, verify the first ambiguous syndrome shell (all weight t+1 errors).
for name in ['G24','G12']:
    s=SPECS[name];p,k,n,d,t,g=s; shell=Counter(syndrome(e,s) for e in errors(n,p,t+1) if sum(x!=0 for x in e)==t+1 and syndrome(e,s) not in tabs[name]); expect=n//(t+1)
    assert len(shell)==p**(n-k)-len(tabs[name]);assert set(shell.values())=={expect}
    stats[name]['first_ambiguous_multiplicity']=expect;stats[name]['ambiguous_syndromes']=len(shell)
# A list decoder for the first ambiguous shell. It preserves all candidates;
# no canonical choice is inferred from the syndrome alone.
ambiguity_tables={}
for name in ('G24','G12'):
    spec=SPECS[name]; p,k,n,d,t,g=spec; shell={}
    for e in errors(n,p,t+1):
        if sum(x!=0 for x in e)!=t+1: continue
        syn=syndrome(e,spec)
        if syn not in tabs[name]: shell.setdefault(syn,[]).append(e)
    ambiguity_tables[name]=shell
    # Every syndrome gives exactly the indicated fibre cardinality; verify
    # each correction on a representative received word (an error vector).
    for syn,es in shell.items():
        y=es[0]; candidates=set()
        for e in es:
            c=tuple((a-b)%p for a,b in zip(y,e)); m,r=division(c,spec)
            assert not any(r) and encode(m,spec)==c
            candidates.add(m)
        assert len(candidates)==n//(t+1)

def nearest_candidates(w,name):
    spec=SPECS[name]; p,k,n,d,t,g=spec
    result=correct(w,spec,tabs[name])
    if result is not None: return [result]
    out=[]
    for e in ambiguity_tables.get(name,{}).get(syndrome(w,spec),[]):
        c=tuple((a-b)%p for a,b in zip(w,e));m,r=division(c,spec)
        assert not any(r) and encode(m,spec)==c
        out.append((m,e))
    return out

# Registered typed term quotation. All fields are length-prefixed UTF-8, including the full formula and hypotheses.
# These are marks for the actual new paper theorem ports, NOT imported historical 1395-bit quotations.
def gamma(n):
    assert n>=1; b=bin(n)[2:];return '0'*(len(b)-1)+b
def field(s):
    b=s.encode(); return gamma(len(b)+1)+''.join(f'{x:08b}' for x in b)
def quote(record):
    vals=['H24-NULL-v1',record['id'],record['source'],record['hypotheses'],record['conclusion'],str(len(record['parents'])),*record['parents'],record['proof_source']]
    return ''.join(field(v) for v in vals)
def anchor(w):
    k=len(w); mod=1<<k; a=0
    # Exact affine inverse of the chronological parity word.
    for i,b in enumerate(w):a=3*a+(int(b)<<i)
    return (-a*pow(pow(3,k,mod),-1,mod))%mod

def decode_address(g):
    if not isinstance(g,int) or g<0: raise ValueError('invalid Godel address')
    k=(g+1).bit_length()-1; a=g+1-(1<<k)
    w=[]
    for _ in range(k):
        b=a%2; w.append(str(b)); a=(3*a+b)//2
    return ''.join(w)

def unquote(w):
    i=0; vals=[]
    while i<len(w):
        z=0
        while i<len(w) and w[i]=='0': z+=1; i+=1
        if i+z>=len(w): raise ValueError('incomplete gamma code')
        length=int(w[i:i+z+1],2)-1; i+=z+1
        end=i+8*length
        if end>len(w): raise ValueError('incomplete quotation field')
        vals.append(bytes(int(w[j:j+8],2) for j in range(i,end,8)).decode('utf-8'))
        i=end
    if len(vals)<7 or vals[0]!='H24-NULL-v1':raise ValueError('bad grammar')
    n=int(vals[5]);
    if n<0 or len(vals)!=7+n:raise ValueError('incorrect parent count')
    return {'id':vals[1],'source':vals[2],'hypotheses':vals[3],
            'conclusion':vals[4],'parents':vals[6:6+n],'proof_source':vals[6+n]}

def verify_parity(a,w):
    for b in w:
        assert a%2==int(b);a=(3*a+int(b))//2

records=json.loads((P/'graph.json').read_text())
source=(P/'paper.tex').read_text()
seen=set();out=[]
for r in records:
    r['proof_source']=source.split('%% BEGIN '+r['id']+'\n',1)[1].split('%% END '+r['id'],1)[0].rstrip()

    assert all(x in seen for x in r['parents']);assert r['id'] not in seen;seen.add(r['id'])
    w=quote(r); k=len(w);a=anchor(w);verify_parity(a,w);g=(1<<k)-1+a
    codes={name:[''.join(map(str,b)) for b in blocks(g,s)] for name,s in SPECS.items()}
    assert decode_address(g)==w and unquote(w)==r
    for name,s in SPECS.items():
        recovered=readblocks([tuple(map(int,b)) for b in codes[name]],s,tabs[name])
        assert recovered==g and unquote(decode_address(recovered))==r
    out.append({**r,'quotation_bits':w,'depth':k,'residue_decimal':str(a),'godel_decimal':str(g),'godel_hex':hex(g),'four_golay':codes,'quotation_sha256':hashlib.sha256(w.encode()).hexdigest()})
(P/'canonical_codes.json').write_text(json.dumps(out,indent=2)+'\n')
receipt={'algebraic_proofs':proof_checks,'golay':stats,'coded_theorem_ports':len(out),'all_four_round_trips':4*len(out),'exact_source_quotation_readbacks':4*len(out),'extended_ambiguity_list_decoders':'all uncovered syndromes checked','formal_provers':{'Lean':'not available; source only','Agda':'not available; source only','Hets':'not available; consequence goals only'},'scope':'exact finite algebraic and coding results; no numerical sample proves a continuum field theorem'}
(P/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
