"""Tests of the codec, comparison and finite-prefix inference ONLY.
These checks are not Millennium theorem verification or proofs of completeness.
"""
import json,itertools,random,copy
from pathlib import Path
from canonical import *
from independent import independent_address
from requirements import all_requirements,HERE
from cycles import integral,verify

def main():
    counts={}; c=0
    for k in range(11):
        for n in range(1<<k):
            w=f'{n:0{k}b}' if k else '';b=Ball.from_word(w)
            assert b.g==independent_address(w) and b.word()==w
            if k:assert Ball.from_word(w[:-1]).a==b.a%(1<<(k-1))
            c+=1
    counts['all_binary_words_through_depth_10']=c
    rng=random.Random(24);c=0
    for m in range(1,65):
        chart=Chart(m)
        for _ in range(5):
            x=tuple(rng.randrange(1<<m) for _ in range(6));assert N(x,m)==chart.encode(x);assert Ni(N(x,m),m)==x
            c+=1
    counts['exact_retained_polylog_comparisons']=c
    # All pair/triple comparison identities of the nine marked split charts.
    m=32;x=(17,33,123,64,507,82);c=0
    def U(j,i,v):return rconj(v,m,j//3-i//3)
    for i,j,k in itertools.product(range(9),repeat=3):
        v=rconj(x,m,i//3);assert U(k,j,U(j,i,v))==U(k,i,v);c+=1
    counts['nine_corner_cocycles']=c
    # Test R preserves the original Gram metric; dagger reverses conjugation.
    G=((1,0,0,1),(0,2,-1,0),(0,-1,2,0),(1,0,0,2));assert mm(mm(tuple(zip(*R)),G),R)==G
    counts['native_rotation_isometry']=1
    c=0;prev=None
    for m in range(1,65):
        r=integral(m);u=[int(x,16) for x in r['resolvent_cut']];assert verify(m,u)
        if prev is not None:assert [x%(1<<(m-1)) for x in u]==prev
        prev=u;c+=1
    counts['compatible_comparison_integral_cuts']=c
    # Strong triangle check for every finite Boolean acceptance stream of length 9.
    c=0
    for n in range(512):
        obs={g:'ACCEPTED_FULL_TARGET' if n>>g&1 else 'REJECTED_CERTIFICATE' for g in range(9)}
        v=cut(None,lambda q,b:obs[b.g],9);a=int(v['residue'],16)
        if n:
            lead=(n&-n).bit_length()-1;assert (a&-a).bit_length()-1==lead and v['minimum']['minimum_certified'] and int(v['minimum']['proof_address'],16)==lead
        else:assert a==0 and v['minimum']['status']=='OPEN'
        c+=1
    counts['strong_triangle_finite_stream_checks']=c
    assert first_occupied({7:'ACCEPTED_FULL_TARGET',0:'OPEN'})['minimum_certified'] is False
    assert cut(None,lambda q,b:'OPEN',1)['residue'] is None
    counts['unknown_is_not_negative_evidence']=2
    # The original seven requirement and actual three generated term packets.
    c=0;bad=0
    for t,q in all_requirements().items():
        r=json.loads((HERE/'results'/(t+'.json')).read_text())
        for p in (r['requirement_cylinder'],r.get('candidate_cylinder')):
            if p is None:continue
            w=decode_views(q['mark'],p);assert independent_address(w)==Ball.load(p['ball']).g;c+=1
            for mutation in ('mark','residue','matrix','corner'):
                z=copy.deepcopy(p)
                if mutation=='mark':z['requirement_mark']='not-original'
                elif mutation=='residue':z['ball']['residue']=hex(int(z['ball']['residue'],16)^1)
                elif mutation=='matrix':z['views'][0]['matrix'][0][0]=hex(int(z['views'][0]['matrix'][0][0],16)^1)
                else:z['views'][0]['corner']=1
                try:decode_views(q['mark'],z)
                except ValueError:bad+=1
                else:raise AssertionError('accepted corrupt '+mutation)
    counts['actual_source_bound_cylinder_roundtrips']=c;counts['altered_packets_rejected']=bad
    # Independent source-level check of grammar constructors incl. universe and binder data.
    # Not statements presented as proofs; merely exercise all admitted tags.
    nm=[['s','test'],['n',3]];lv=['max',['succ',['zero']],['imax',['param',nm],['zero']]]
    e=['let',nm,['sort',lv],['nat',17],['proj',nm,2,['mdata',['app',['lam',nm,'instance',['sort',['zero']],['bvar',0]],['string','λ']]]],False]
    for x in (e,['forall',nm,'strict_implicit',['sort',lv],['const',nm,[lv]]]):assert read('expr',enc('expr',x))==x
    counts['additional_structural_grammar_checks']=2
    print(json.dumps(counts,indent=2));(HERE/'results'/'test_receipt.json').write_text(json.dumps(counts,indent=2)+'\n')
if __name__=='__main__':main()
