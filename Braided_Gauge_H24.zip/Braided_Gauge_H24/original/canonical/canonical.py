"""Direct canonical base-3/2 cylinders of the fixed Lean certificate grammar.
No JSON bytes or arbitrary Python value codec occur in the address or its inverse.
A candidate expression is not a proof until the independent fixed verifier accepts it.
"""
from dataclasses import dataclass
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent/'sources'))
from native_chart import Chart, minimum_grammar

# Structural word grammar. Tags are fixed; nat(n) is gamma(n+1).
EXPR=(('bvar','nat'),('sort','level'),('const','name','levels'),('app','expr','expr'),
      ('lam','name','binder','expr','expr'),('forall','name','binder','expr','expr'),
      ('let','name','expr','expr','expr','bool'),('nat','nat'),('string','string'),
      ('proj','name','nat','expr'),('mdata','expr'))
LEVEL=(('zero',),('succ','level'),('max','level','level'),('imax','level','level'),('param','name'))
BIND=('explicit','implicit','strict_implicit','instance')
LISTS={'levels':'level','names':'name','decls':'decl','types':'indtype','ctors':'ctor'}
FIELDS={'ctor':(('name','name'),('type','expr')),'indtype':(('name','name'),('type','expr'),('ctors','ctors'))}

def nat(n):
    if type(n) is not int or n<0: raise ValueError('natural required')
    a=bin(n+1)[2:]; return '0'*(len(a)-1)+a

def enc(t,x):
    if t=='nat':return nat(x)
    if t=='bool':
        if type(x) is not bool: raise ValueError('boolean')
        return str(int(x))
    if t=='string':
        if not isinstance(x,str):raise ValueError('string')
        a=x.encode('utf-8');return nat(len(a))+''.join(f'{b:08b}' for b in a)
    if t=='binder':return f'{BIND.index(x):02b}'
    if t=='name':
        if not isinstance(x,list):raise ValueError('name')
        out=[]
        for tag,s in x:
            if tag not in ('s','n'):raise ValueError('name segment')
            out.append(('0'+enc('string',s)) if tag=='s' else ('1'+nat(s)))
        return nat(len(x))+''.join(out)
    if t in LISTS:
        if not isinstance(x,list):raise ValueError('list')
        return nat(len(x))+''.join(enc(LISTS[t],v) for v in x)
    if t in ('expr','level'):
        table=EXPR if t=='expr' else LEVEL
        k=next((i for i,v in enumerate(table) if v[0]==x[0]),None)
        if k is None or len(x)!=len(table[k]):raise ValueError('unsupported constructor or arity')
        return f'{k:0{4 if t=="expr" else 3}b}'+''.join(enc(s,v) for s,v in zip(table[k][1:],x[1:]))
    if t=='decl':
        k=('theorem','def','inductive').index(x['kind'])
        f=(('name','name'),('level_params','names'),('type','expr'),('value','expr')) if k<2 else (('level_params','names'),('num_params','nat'),('types','types'))
        if set(x)!= {'kind',*(n for n,_ in f)}:raise ValueError('declaration fields')
        return f'{k:02b}'+''.join(enc(s,x[n]) for n,s in f)
    if t in FIELDS:
        f=FIELDS[t]
        if set(x)!={n for n,_ in f}:raise ValueError('field set')
        return ''.join(enc(s,x[n]) for n,s in f)
    raise ValueError('unknown sort')

class Reader:
    def __init__(self,w):self.w=w;self.i=0
    def take(self,n):
        if n<0 or n>len(self.w)-self.i:raise ValueError('truncated code')
        v=self.w[self.i:self.i+n];self.i+=n;return v
    def num(self,n):return int(self.take(n),2)
    def nat(self):
        j=0
        while self.take(1)=='0':j+=1
        return (1<<j)+(self.num(j) if j else 0)-1
    def count(self):
        n=self.nat()
        if n>len(self.w)-self.i:raise ValueError('list count beyond remaining word')
        return n
    def read(self,t):
        if t=='nat':return self.nat()
        if t=='bool':return bool(self.num(1))
        if t=='string':return bytes(self.num(8) for _ in range(self.count())).decode('utf-8')
        if t=='binder':return BIND[self.num(2)]
        if t=='name':
            return [['n',self.nat()] if self.num(1) else ['s',self.read('string')] for _ in range(self.count())]
        if t in LISTS:return [self.read(LISTS[t]) for _ in range(self.count())]
        if t in ('expr','level'):
            tab=EXPR if t=='expr' else LEVEL;k=self.num(4 if t=='expr' else 3)
            if k>=len(tab):raise ValueError('unknown tag')
            return [tab[k][0],*(self.read(s) for s in tab[k][1:])]
        if t=='decl':
            k=self.num(2)
            if k==3:raise ValueError('unknown decl')
            f=(('name','name'),('level_params','names'),('type','expr'),('value','expr')) if k<2 else (('level_params','names'),('num_params','nat'),('types','types'))
            return {'kind':('theorem','def','inductive')[k],**{n:self.read(s) for n,s in f}}
        if t in FIELDS:return {n:self.read(s) for n,s in FIELDS[t]}
        raise ValueError('unknown sort')

def read(t,w):
    r=Reader(w);x=r.read(t)
    if r.i!=len(w) or enc(t,x)!=w:raise ValueError('not canonical complete word')
    return x

def certificate_word(c):
    v2=c['schema']=='programme.kernel-proof-certificate.v2'
    if c['schema'] not in ('programme.kernel-proof-certificate.v1','programme.kernel-proof-certificate.v2'):raise ValueError('schema')
    fields={'schema','target_id','branch','root','declarations'}|({'root_universe_arguments'} if v2 else set())
    if set(c)!=fields:raise ValueError('certificate fields')
    return enc('bool',v2)+enc('name',c['root'])+enc('decls',c['declarations'])+(enc('levels',c['root_universe_arguments']) if v2 else '')

def certificate_from_word(q,w):
    # The target and branch come from the independently fixed requirement,
    # never from the candidate. No new axioms or free metavariables in grammar.
    r=Reader(w);v2=r.read('bool');root=r.read('name');ds=r.read('decls')
    c={'schema':'programme.kernel-proof-certificate.v'+('2' if v2 else '1'),
       'target_id':q['target_id'],'branch':q['branch'],'root':root,'declarations':ds}
    if v2:c['root_universe_arguments']=r.read('levels')
    if r.i!=len(w) or certificate_word(c)!=w:raise ValueError('not canonical certificate')
    return c

@dataclass(frozen=True)
class Ball:
    g:int
    def __post_init__(self):
        if type(self.g) is not int or self.g<0:raise ValueError('natural Godel address required')
    @property
    def k(self):return (self.g+1).bit_length()-1
    @property
    def a(self):return self.g-((1<<self.k)-1)
    def record(self):return {'g':hex(self.g),'depth':self.k,'residue':hex(self.a)}
    @staticmethod
    def load(x):
        b=Ball(int(x['g'],16))
        if b.g<0 or b.record()!=x:raise ValueError('inconsistent canonical address')
        return b
    @staticmethod
    def from_word(w):
        if any(c not in '01' for c in w):raise ValueError('binary word')
        k=len(w)
        if not k:return Ball(0)
        M=1<<k; inv=pow(3,-1,M);a=0
        for c in reversed(w):a=(2*a-int(c))*inv%M
        return Ball(M-1+a)
    def word(self):
        a=self.a;w=[]
        for _ in range(self.k):
            b=a&1;w.append(str(b));a=(3*a+b)//2
        return ''.join(w)

# Same retained odd Lerch/polylogarithm tau with s=2,lambda=-1;
# accelerated evaluation of its finite cut and Newton inverse.
def tau_and_deriv(x,m):
    M=1<<m;x%=M;z=(-4*x*x)%M;p=1;a=0;d=0
    for j in range((m+1)//2):
        if not p:break
        inv=pow(2*j+1,-1,M);a=(a+p*inv*inv)%M;d=(d+p*inv)%M;p=p*z%M
    return x*a%M,d

def untau(y,m):
    x=y&1;k=1
    while k<m:
        q=min(2*k,m);M=1<<q;f,d=tau_and_deriv(x,q)
        x=(x+(y-f)*pow(d,-1,M))%M;k=q
    return x

def N(xs,m):
    c=Chart(m);return c.rho(c.ND(c.NU(tuple(tau_and_deriv(x,m)[0] for x in xs))))

def Ni(A,m):
    c=Chart(m);A=tuple(tuple(r) for r in A)
    if c.rho(c.delta(A))!=A:raise ValueError('not native matrix')
    y=c.L(c.L(c.delta(A),c.D),c.U)
    return tuple(untau(v,m) for v in y)

def mm(A,B):return tuple(tuple(sum(a*b for a,b in zip(r,c)) for c in zip(*B)) for r in A)
R=((1,0,0,0),(0,0,-1,0),(0,1,-1,0),(0,0,0,1));I=tuple(tuple(int(i==j) for j in range(4)) for i in range(4));R2=mm(R,R)
RP=(I,R,R2)
assert mm(R,R2)==I

def rconj(xs,m,j):
    c=Chart(m);A=mm(mm(RP[j%3],c.rho(xs)),RP[(-j)%3]);return c.red(c.delta(A))

# Nine views of the SAME ball. Do not identify the requirement with a proof.
# H advances block j%3, acts by R conjugation on wrapping; H^3 acts by R.
def nested_views(ball,requirement_mark):
    m=max(1,ball.k);xs=(0,0,ball.a,0,0,0)
    matrices=[N(rconj(xs,m,j),m) for j in range(3)]
    return {'requirement_mark':requirement_mark,'ball':ball.record(),'aperture':m,
            'views':[{'corner':i,'block':i%3,'frame':i//3,'matrix':[[hex(v) for v in row] for row in matrices[i//3]]} for i in range(9)]}

def decode_views(qmark,p):
    if p['requirement_mark']!=qmark:raise ValueError('wrong dependent requirement')
    b=Ball.load(p['ball']);m=max(1,b.k)
    if m!=p['aperture'] or len(p['views'])!=9:raise ValueError('aperture/views')
    cache={}
    for i,v in enumerate(p['views']):
        if (v['corner'],v['block'],v['frame'])!=(i,i%3,i//3):raise ValueError('cycle mark')
        key=tuple(tuple(int(x,16) for x in row) for row in v['matrix'])
        if key not in cache:cache[key]=Ni(key,m)
        x=rconj(cache[key],m,-(i//3))
        if x!=(0,0,b.a,0,0,0):raise ValueError('wrong canonical ball return')
    return b.word()

# Partial verifier observations: UNKNOWN is never a rejection.
def first_occupied(obs):
    # Finite certified observations of a lazy generator, not enumeration by default.
    if any(type(g) is not int or g<0 for g in obs):raise ValueError('address index')
    hits=sorted(g for g,s in obs.items() if s=='ACCEPTED_FULL_TARGET')
    if not hits:return {'status':'OPEN','proof_address':None,'minimum_certified':False}
    g=hits[0]
    # Check coverage by cardinality of distinct nonnegative earlier rejected addresses.
    # Optional symbolic coverage belongs to a separately checked theorem, not a bool.
    covered=sum(1 for j,s in obs.items() if 0<=j<g and s=='REJECTED_CERTIFICATE')==g
    return {'status':'PROVED','proof_address':hex(g),'minimum_certified':covered,'depth':Ball(g).k}

# Finite adjoint for the canonical accepted-address indicator. Querying a
# coefficient is a source verifier operation; no runtime => unknown.
def cut(q,observe,m):
    if m<1:raise ValueError('positive precision')
    obs={g:observe(q,Ball(g)) for g in range(m)}
    if any(v not in ('ACCEPTED_FULL_TARGET','REJECTED_CERTIFICATE') for v in obs.values()):
        return {'status':'OPEN','precision':m,'observations':obs,'residue':None}
    M=1<<m;z=2*pow(3,-1,M)%M
    x=-pow(3,-1,M)*sum(pow(z,g,M) for g,v in obs.items() if v=='ACCEPTED_FULL_TARGET')%M
    return {'status':'EXACT_CUT','precision':m,'residue':hex(x),'minimum':first_occupied(obs)}
