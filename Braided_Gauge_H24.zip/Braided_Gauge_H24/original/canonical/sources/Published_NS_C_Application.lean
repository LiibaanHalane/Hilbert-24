import NavierStokes.ComparatorR3Theorem

set_option autoImplicit false

noncomputable section

namespace Programme.PublishedRouteApplication

def OriginalWholeSpaceC : Prop :=
  ∀ (nu : ℝ), nu > 0 →
    ∃ (initial : EuclideanSpace ℝ (Fin 3) → EuclideanSpace ℝ (Fin 3))
      (force : EuclideanSpace ℝ (Fin 3) → ℝ → EuclideanSpace ℝ (Fin 3)),
      NavierStokes.Comparator.InitialVelocityConditionDecay initial ∧
      NavierStokes.Comparator.ForceConditionDecay force ∧
      ¬ (∃ velocity pressure,
        NavierStokes.Comparator.NavierStokesExistenceAndSmoothnessRn
          nu initial force velocity pressure)

theorem closedWholeSpaceC : OriginalWholeSpaceC :=
  NavierStokes.ComparatorBridge.navier_stokes_breakdown_R3

theorem returnedOriginalForce (nu : ℝ) (positive : nu > 0) :
    ∃ (initial : EuclideanSpace ℝ (Fin 3) → EuclideanSpace ℝ (Fin 3))
      (force : EuclideanSpace ℝ (Fin 3) → ℝ → EuclideanSpace ℝ (Fin 3)),
      NavierStokes.Comparator.InitialVelocityConditionDecay initial ∧
      NavierStokes.Comparator.ForceConditionDecay force ∧
      ¬ (∃ velocity pressure,
        NavierStokes.Comparator.NavierStokesExistenceAndSmoothnessRn
          nu initial force velocity pressure) := by
  obtain ⟨u, p, f, K, candidate, excludesGlobal⟩ := NavierStokesR3.theorem_1_1 nu positive
  exact NavierStokesR3.comparator_of_breakdown candidate excludesGlobal

end Programme.PublishedRouteApplication

#print axioms Programme.PublishedRouteApplication.closedWholeSpaceC
#print axioms Programme.PublishedRouteApplication.returnedOriginalForce
