import Problems.PVersusNP.Millennium
import Problems.RiemannHypothesis.Millennium
import Problems.NavierStokes.Millennium
import Problems.BirchSwinnertonDyer.Millennium
import Problems.Poincare.Millennium

/-!
Fixed mathematical target declarations recovered from the pinned source project.

Lean: leanprover/lean4:v4.31.0
Problems: 603053dc267cf3efe422f438eb78098c0ececd6f
Mathlib: fabf563a7c95a166b8d7b6efca11c8b4dc9d911f

These aliases retain the original mathematical quantifiers. A verifier compares
the complete candidate declaration type with one selected alias. In particular,
the P-versus-NP branches are separate propositions, not their excluded-middle
disjunction. The four Navier--Stokes alternatives are also separately selected.

The recovered BSD repository proposition is the Taylor-order/rank variant.
It is recorded in RepositoryVariants, separately from the user's full refined
arithmetic-normalization target. The recovered Hodge and Yang--Mills repository
propositions have the recorded upstream status `statement_incomplete`. Their
expanded source-language definitions, and the refined BSD definitions, are
preserved verbatim in Full_Target_Source_Type_Definitions.txt.

This module introduces no theorem asserting any target and no new axiom.
It is source for the pinned 4.31 project, not a fresh 4.19 build receipt.
-/

namespace Programme.TrustedMillennium

universe u

abbrev PEqualsNPStatement : Prop := Millennium.ClayPVersusNP

abbrev PNotEqualsNPStatement : Prop :=
  Millennium.ClayPVersusNP.Formulations.NegativeBranch

abbrev RiemannStatement : Prop := _root_.RiemannHypothesis

abbrev NavierStokesAStatement : Prop := MillenniumNavierStokes.FeffermanA
abbrev NavierStokesBStatement : Prop := MillenniumNavierStokes.FeffermanB
abbrev NavierStokesCStatement : Prop := MillenniumNavierStokes.FeffermanC
abbrev NavierStokesDStatement : Prop := MillenniumNavierStokes.FeffermanD

abbrev PoincareStatement : Prop :=
  MillenniumPoincare.ClayPoincareConjecture.{u}

inductive PNPBranch where
  | equality
  | separation
  deriving DecidableEq, Repr

def PNPStatement : PNPBranch → Prop
  | .equality => PEqualsNPStatement
  | .separation => PNotEqualsNPStatement

inductive NavierStokesBranch where
  | A
  | B
  | C
  | D
  deriving DecidableEq, Repr

def NavierStokesStatement : NavierStokesBranch → Prop
  | .A => NavierStokesAStatement
  | .B => NavierStokesBStatement
  | .C => NavierStokesCStatement
  | .D => NavierStokesDStatement

namespace RepositoryVariants

abbrev BSDTaylorRankStatement : Prop :=
  MillenniumBirchSwinnertonDyer.ClayBirchSwinnertonDyer

end RepositoryVariants

end Programme.TrustedMillennium
