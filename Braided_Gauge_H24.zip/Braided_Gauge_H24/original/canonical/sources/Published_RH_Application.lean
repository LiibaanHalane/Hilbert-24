import Main
import Applied_Analytic_Source_Returns

set_option autoImplicit false

noncomputable section

namespace Programme.PublishedRouteApplication

theorem closedRiemann : Programme.TrustedMillennium.RiemannStatement :=
  _root_.riemannHypothesis

theorem riemannViaSavedConstructor
    (ambient : Programme.OriginalTargets.Signature.{0})
    (input : Programme.OriginalTargets.RHQuestion
      (Programme.PostmortemConcrete.riemannSignature ambient) →
      NativeDyadicSolver.ActualGram.NativeSpace) :
    Programme.TrustedMillennium.RiemannStatement :=
  Programme.PostmortemConcrete.applied_original_riemann ambient closedRiemann input

end Programme.PublishedRouteApplication

#print axioms Programme.PublishedRouteApplication.closedRiemann
#print axioms Programme.PublishedRouteApplication.riemannViaSavedConstructor
