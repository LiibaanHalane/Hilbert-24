"""Exact finite-aperture reference for the six-stream H24 chart.
The chart does NOT compute CNF histograms from succinct CNFs; that input
is separate.  The grammar constructor works on explicitly supplied rules.
No external dependencies. Run: python quantized_belnap_h24.py
"""
from random import Random

class Chart:
    def __init__(self, bits, s=2, lam=-1):
        assert bits >= 1 and s >= 0
        self.bits=bits; self.mod=1<<bits; self.s=s; self.lam=lam
    def red(self, xs): return tuple(x%self.mod for x in xs)
    def D(self, x):
        t,b,p,h,r,k=x; m=self.mod; inv3=pow(3,-1,m)
        # H^-1 B^T H, H=[[2,-1],[-1,2]]
        a,c,d,e=2*p-r,-p+2*r,2*h-k,-h+2*k
        return self.red((t,b,inv3*(2*a+d),inv3*(2*c+e),inv3*(a+2*d),inv3*(c+2*e)))
    def U(self,x): return x[1:]+x[:1]
    def L(self,x,F): return self.red(a-2*b for a,b in zip(x,F(x)))
    def ND(self,x):
        c=-pow(3,-1,self.mod)
        return self.red(c*(a+2*b) for a,b in zip(x,self.D(x)))
    def NU(self,x):
        y=x; acc=[0]*6
        for j in range(6):
            for i in range(6): acc[i]+=2**j*y[i]
            y=self.U(y)
        return self.red(-pow(63,-1,self.mod)*a for a in acc)
    def tau(self,u):
        m=self.mod; u%=m
        return sum(pow(4,j,m)*pow(self.lam,j,m)*pow(u,2*j+1,m)*pow(pow(2*j+1,self.s,m),-1,m) for j in range((self.bits+1)//2))%m
    def untau(self,y):
        y%=self.mod; x=y
        for _ in range((self.bits+1)//2): x=(y+x-self.tau(x))%self.mod
        return x
    def rho(self,x):
        t,b,p,h,r,k=x; m=self.mod
        return (((t-2*b)%m,0,0,0),(0,p,h,0),(0,r,k,0),(b,0,0,t))
    def delta(self,A): return (A[3][3],A[3][0],A[1][1],A[1][2],A[2][1],A[2][2])
    def encode(self,x): return self.rho(self.ND(self.NU(tuple(self.tau(u) for u in x))))
    def decode(self,A): return tuple(self.untau(u) for u in self.L(self.L(self.delta(A),self.D),self.U))
    def project(self,A,i):
        x=self.decode(A); return self.encode(tuple(u if j==i else 0 for j,u in enumerate(x)))
    def valuation(self,A):
        z=[(u&-u).bit_length()-1 for row in A for u in row if u]
        return min(z,default=self.bits)

def moment_product(a,b):
    z,u,v=a; q,r,s=b
    return (z*q,u*q+z*r,v*q+2*u*r+z*s)

def update(a,l,e,q):
    z,u,v=a; w=l*q**e
    return (w*z,w*(u+e*z),w*(v+2*e*u+e*e*z))

def compare_packed_children(R0,R1,d,m):
    """Inputs: genuine packed child histograms, common radix 2^(d+1).
    Nonempty child fibres, m maximum charge. Return minimum-containing bit."""
    b=d+1; ch=Chart(b*(m+1))
    assert 0<R0<ch.mod and 0<R1<ch.mod
    A=ch.encode((R0,0,0,R1,0,0))
    v0=ch.valuation(ch.project(A,0)); v1=ch.valuation(ch.project(A,3))
    return int(v1<v0), (v0//b,v1//b)

def minimum_grammar(n,rules):
    """Rules (head, tuple of premise judgement IDs, nonnegative charge).
    Explicit finite judgement set [0,n).  Returns minimum grades and a
    staged attaining proof DAG; unfolding may be exponentially larger."""
    assert n>=1
    rows=[([None]*n,[None]*n)]
    for t in range(1,n+1):
        prev=rows[-1][0]; cost=[None]*n; witness=[None]*n
        for i,(v,us,c) in enumerate(rules):
            assert 0<=v<n and c>=0 and all(0<=u<n for u in us)
            if any(prev[u] is None for u in us): continue
            w=c+sum(prev[u] for u in us)
            if cost[v] is None or w<cost[v]: cost[v]=w; witness[v]=i
        rows.append((cost,witness))
    return rows[-1][0],rows

def check():
    rng=Random(24); chart_checks=0; branch_checks=0; moment_checks=0
    for bits in range(1,33):
        c=Chart(bits)
        for _ in range(10):
            x=tuple(rng.randrange(c.mod) for _ in range(6)); y=tuple(rng.randrange(c.mod) for _ in range(6))
            assert c.D(c.D(x))==x and c.L(c.ND(x),c.D)==x and c.L(c.NU(x),c.U)==x
            assert c.decode(c.encode(x))==x
            assert c.valuation(c.encode(c.red(a-b for a,b in zip(x,y))))==c.valuation(c.rho(c.red(a-b for a,b in zip(x,y))))
            chart_checks+=1
    for d in range(1,9):
        for _ in range(20):
            m=rng.randrange(1,9); b=d+1
            a=[rng.randrange(m+1) for _ in range(1<<(d-1))]; z=[rng.randrange(m+1) for _ in a]
            R=[sum(1<<(b*j) for j in h) for h in (a,z)]
            bit, mins=compare_packed_children(*R,d,m)
            assert mins==(min(a),min(z)) and mins[bit]==min(mins)
            branch_checks+=1
    for _ in range(100):
        q=rng.randrange(1,5); a=[rng.randrange(6) for _ in range(4)]; b=[rng.randrange(6) for _ in range(3)]
        mom=lambda xs: tuple(sum(j**i*q**j for j in xs) for i in range(3))
        assert moment_product(mom(a),mom(b))==mom([x+y for x in a for y in b])
        assert update(update(mom(a),2,1,q),3,2,q)==update(mom(a),6,3,q)
        moment_checks+=1
    # Finite cyclic grammar with an uninhabited self-loop, zero cycle,
    # a costly axiom, and a cheaper two-premise derivation.
    rules=[(0,(),3),(1,(),2),(2,(0,1),1),(2,(),12),(0,(2,),0),(3,(3,),0)]
    costs,rows=minimum_grammar(4,rules)
    assert costs==[3,2,6,None]
    print(f'{chart_checks} chart checks; {branch_checks} packed branch checks; {moment_checks} moment checks; cyclic grammar minimum {costs}.')

if __name__=='__main__': check()
