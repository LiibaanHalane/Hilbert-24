import DifferentialGeometry.Topology.ThreeManifold.Poincare
import Applied_Analytic_Source_Returns

set_option autoImplicit false

noncomputable section

namespace Programme.PublishedRouteApplication

universe u

theorem closedPoincare : Programme.TrustedMillennium.PoincareStatement.{u} := by
  intro M top t2 second charts simple compact
  exact DifferentialGeometry.Topology.poincare_conjecture M

theorem poincareViaSavedConstructor
    (ambient : Programme.OriginalTargets.Signature.{u+1})
    (input : Programme.OriginalTargets.PoincareQuestion
      (Programme.PostmortemConcrete.poincareSignature ambient) →
      NativeDyadicSolver.ActualGram.NativeSpace) :
    Programme.TrustedMillennium.PoincareStatement.{u} :=
  Programme.PostmortemConcrete.applied_original_poincare ambient closedPoincare input

end Programme.PublishedRouteApplication

#print axioms Programme.PublishedRouteApplication.closedPoincare
#print axioms Programme.PublishedRouteApplication.poincareViaSavedConstructor
