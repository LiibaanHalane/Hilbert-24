import P_Concrete_Machine_Interpretation
import NS_Actual_Branch_Return
import Applied_Analytic_Source_Returns

namespace Programme.TrustedMillennium

def ReturnedNavierStokesAlternativeStatement : Prop :=
  NavierStokesAStatement ∨
    (NavierStokesBStatement ∨
      (NavierStokesCStatement ∨ NavierStokesDStatement))

theorem returned_alternative_exact :
    ReturnedNavierStokesAlternativeStatement =
      (NavierStokesAStatement ∨
        (NavierStokesBStatement ∨
          (NavierStokesCStatement ∨ NavierStokesDStatement))) := rfl

end Programme.TrustedMillennium
