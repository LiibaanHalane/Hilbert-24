import Lean

/-!
Structural transport of Lean's actual expression and universe syntax.
Every node carries its atomic head in a marked 4-by-4 typed matrix and keeps
its recursive children separately. No head stores an opaque Lean.Expr.
The twelve expression constructors occupy twelve of the sixteen cells.
-/
set_option autoImplicit false
namespace Programme.LeanTorserSyntax
open Lean

def row (tag : Fin 16) : Fin 4 := ⟨tag.val / 4, by omega⟩
def col (tag : Fin 16) : Fin 4 := ⟨tag.val % 4, by omega⟩

structure Head (tag : Fin 16) (A : Type) where
  cells : Fin 4 → Fin 4 → Option A
  occupied : (cells (row tag) (col tag)).isSome = true
  shape : ∀ i j, cells i j =
    if i = row tag ∧ j = col tag then cells (row tag) (col tag) else none

theorem Head.ext {tag : Fin 16} {A : Type} {h k : Head tag A}
    (same : h.cells = k.cells) : h = k := by
  cases h; cases k; cases same; rfl

def encodeHead {A : Type} (tag : Fin 16) (a : A) : Head tag A where
  cells := fun i j => if i = row tag ∧ j = col tag then some a else none
  occupied := by simp
  shape := by intros; simp

def decodeHead {tag : Fin 16} {A : Type} (head : Head tag A) : A :=
  (head.cells (row tag) (col tag)).get head.occupied

@[simp] theorem decode_encode_head {A : Type} (tag : Fin 16) (a : A) :
    decodeHead (encodeHead tag a) = a := by simp [decodeHead, encodeHead]

@[simp] theorem encode_decode_head {tag : Fin 16} {A : Type} (head : Head tag A) :
    encodeHead tag (decodeHead head) = head := by
  apply Head.ext
  funext i j
  rw [head.shape i j]
  change (if i = row tag ∧ j = col tag then
    some ((head.cells (row tag) (col tag)).get head.occupied) else none) = _
  rw [Option.some_get head.occupied]

@[simp] theorem unit_head (tag : Fin 16) (head : Head tag Unit) :
    encodeHead tag () = head := by
  have h := encode_decode_head head
  cases decodeHead head
  exact h

inductive LevelCode where
  | zero (head : Head 0 Unit)
  | succ (head : Head 1 Unit) (level : LevelCode)
  | max (head : Head 2 Unit) (left right : LevelCode)
  | imax (head : Head 3 Unit) (left right : LevelCode)
  | param (head : Head 4 Name)
  | mvar (head : Head 5 LMVarId)

def encodeLevel : Level → LevelCode
  | .zero => .zero (encodeHead 0 ())
  | .succ u => .succ (encodeHead 1 ()) (encodeLevel u)
  | .max u v => .max (encodeHead 2 ()) (encodeLevel u) (encodeLevel v)
  | .imax u v => .imax (encodeHead 3 ()) (encodeLevel u) (encodeLevel v)
  | .param n => .param (encodeHead 4 n)
  | .mvar n => .mvar (encodeHead 5 n)

def decodeLevel : LevelCode → Level
  | .zero _ => .zero
  | .succ _ u => .succ (decodeLevel u)
  | .max _ u v => .max (decodeLevel u) (decodeLevel v)
  | .imax _ u v => .imax (decodeLevel u) (decodeLevel v)
  | .param h => .param (decodeHead h)
  | .mvar h => .mvar (decodeHead h)

@[simp] theorem decode_encode_level (u : Level) : decodeLevel (encodeLevel u) = u := by
  induction u <;> simp_all [encodeLevel, decodeLevel]

@[simp] theorem encode_decode_level (u : LevelCode) : encodeLevel (decodeLevel u) = u := by
  induction u <;> simp_all [encodeLevel, decodeLevel]
  all_goals exact unit_head _ _

inductive ExprCode where
  | bvar (head : Head 0 Nat)
  | fvar (head : Head 1 FVarId)
  | mvar (head : Head 2 MVarId)
  | sort (head : Head 3 Unit) (level : LevelCode)
  | const (head : Head 4 Name) (levels : List LevelCode)
  | app (head : Head 5 Unit) (fn arg : ExprCode)
  | lam (head : Head 6 (Name × BinderInfo)) (type body : ExprCode)
  | forallE (head : Head 7 (Name × BinderInfo)) (type body : ExprCode)
  | letE (head : Head 8 (Name × Bool)) (type value body : ExprCode)
  | lit (head : Head 9 Literal)
  | mdata (head : Head 10 MData) (body : ExprCode)
  | proj (head : Head 11 (Name × Nat)) (struct : ExprCode)

def encodeExpr : Expr → ExprCode
  | .bvar i => .bvar (encodeHead 0 i)
  | .fvar i => .fvar (encodeHead 1 i)
  | .mvar i => .mvar (encodeHead 2 i)
  | .sort u => .sort (encodeHead 3 ()) (encodeLevel u)
  | .const name levels => .const (encodeHead 4 name) (levels.map encodeLevel)
  | .app f x => .app (encodeHead 5 ()) (encodeExpr f) (encodeExpr x)
  | .lam name type body bi =>
      .lam (encodeHead 6 (name, bi)) (encodeExpr type) (encodeExpr body)
  | .forallE name type body bi =>
      .forallE (encodeHead 7 (name, bi)) (encodeExpr type) (encodeExpr body)
  | .letE name type value body nonDep =>
      .letE (encodeHead 8 (name, nonDep)) (encodeExpr type) (encodeExpr value) (encodeExpr body)
  | .lit value => .lit (encodeHead 9 value)
  | .mdata data body => .mdata (encodeHead 10 data) (encodeExpr body)
  | .proj name index struct => .proj (encodeHead 11 (name, index)) (encodeExpr struct)

def decodeExpr : ExprCode → Expr
  | .bvar h => .bvar (decodeHead h)
  | .fvar h => .fvar (decodeHead h)
  | .mvar h => .mvar (decodeHead h)
  | .sort _ u => .sort (decodeLevel u)
  | .const h levels => .const (decodeHead h) (levels.map decodeLevel)
  | .app _ f x => .app (decodeExpr f) (decodeExpr x)
  | .lam h type body => .lam (decodeHead h).1 (decodeExpr type) (decodeExpr body) (decodeHead h).2
  | .forallE h type body => .forallE (decodeHead h).1 (decodeExpr type) (decodeExpr body) (decodeHead h).2
  | .letE h type value body =>
      .letE (decodeHead h).1 (decodeExpr type) (decodeExpr value) (decodeExpr body) (decodeHead h).2
  | .lit h => .lit (decodeHead h)
  | .mdata h body => .mdata (decodeHead h) (decodeExpr body)
  | .proj h struct => .proj (decodeHead h).1 (decodeHead h).2 (decodeExpr struct)

@[simp] theorem decode_encode_expr (e : Expr) : decodeExpr (encodeExpr e) = e := by
  induction e <;> simp_all [encodeExpr, decodeExpr, List.map_map, Function.comp_def]

@[simp] theorem encode_decode_expr (e : ExprCode) : encodeExpr (decodeExpr e) = e := by
  induction e <;> simp_all [encodeExpr, decodeExpr, List.map_map, Function.comp_def]
  all_goals first | exact unit_head _ _ | exact encode_decode_head _

def levelTag : LevelCode → Fin 16
  | .zero _ => 0
  | .succ _ _ => 1
  | .max _ _ _ => 2
  | .imax _ _ _ => 3
  | .param _ => 4
  | .mvar _ => 5

def exprTag : ExprCode → Fin 16
  | .bvar _ => 0
  | .fvar _ => 1
  | .mvar _ => 2
  | .sort _ _ => 3
  | .const _ _ => 4
  | .app _ _ _ => 5
  | .lam _ _ _ => 6
  | .forallE _ _ _ => 7
  | .letE _ _ _ _ => 8
  | .lit _ => 9
  | .mdata _ _ => 10
  | .proj _ _ => 11

def levelNodes : LevelCode → Nat
  | .zero _ | .param _ | .mvar _ => 1
  | .succ _ u => 1 + levelNodes u
  | .max _ u v | .imax _ u v => 1 + levelNodes u + levelNodes v

def exprNodes : ExprCode → Nat
  | .bvar _ | .fvar _ | .mvar _ | .lit _ => 1
  | .sort _ u => 1 + levelNodes u
  | .const _ us => 1 + (us.map levelNodes).foldl Nat.add 0
  | .app _ f x | .lam _ f x | .forallE _ f x => 1 + exprNodes f + exprNodes x
  | .letE _ t v b => 1 + exprNodes t + exprNodes v + exprNodes b
  | .mdata _ b | .proj _ b => 1 + exprNodes b

def exprChildren : ExprCode → List ExprCode
  | .app _ f x | .lam _ f x | .forallE _ f x => [f, x]
  | .letE _ t v b => [t, v, b]
  | .mdata _ b | .proj _ b => [b]
  | _ => []

/-- A dependent requirement keeps the exact binder header and its domain. -/
structure BinderCode where
  head : Head 7 (Name × BinderInfo)
  domain : ExprCode

/-- Bound occurrences in later domains and the result retain their original
de Bruijn indices. This operation does not replace dependencies by atoms. -/
def splitForall : ExprCode → List BinderCode × ExprCode
  | .forallE head domain body =>
      let (binders, result) := splitForall body
      (⟨head, domain⟩ :: binders, result)
  | e => ([], e)

def joinForall : List BinderCode → ExprCode → ExprCode
  | [], result => result
  | b :: bs, result => .forallE b.head b.domain (joinForall bs result)

theorem join_split_forall (e : ExprCode) :
    joinForall (splitForall e).1 (splitForall e).2 = e := by
  induction e <;> simp_all [splitForall, joinForall]

def transportOperation (f : Expr → Expr) (e : ExprCode) : ExprCode :=
  encodeExpr (f (decodeExpr e))

theorem transported_operation_exact (f : Expr → Expr) (e : Expr) :
    decodeExpr (transportOperation f (encodeExpr e)) = f e := by
  simp [transportOperation]

theorem transported_operation_identity (e : ExprCode) :
    transportOperation id e = e := by simp [transportOperation]

theorem transported_operation_composition (f g : Expr → Expr) (e : ExprCode) :
    transportOperation f (transportOperation g e) = transportOperation (f ∘ g) e := by
  simp [transportOperation]

theorem expr_roundtrip_preserves_any_judgment (J : Expr → Prop) (e : Expr) :
    J (decodeExpr (encodeExpr e)) ↔ J e := by rw [decode_encode_expr]

theorem type_and_term_return (type term : Expr) :
    (decodeExpr (encodeExpr type), decodeExpr (encodeExpr term)) = (type, term) := by
  rw [decode_encode_expr, decode_encode_expr]

theorem context_type_term_judgment_return
    (J : List Expr → Expr → Expr → Prop) (context : List Expr) (type term : Expr) :
    J ((context.map encodeExpr).map decodeExpr)
      (decodeExpr (encodeExpr type)) (decodeExpr (encodeExpr term)) ↔
      J context type term := by
  simp [List.map_map, Function.comp_def]

end Programme.LeanTorserSyntax

/-! Data-only certificates. The caller appends a trusted, fixed configuration
and `main`; candidate files contain no Lean commands, imports, or options.
Expression metadata is omitted from the wire format. Every decoded logical
expression passes through the exact torser syntax return before kernel use. -/
namespace Programme.DataProofGate
open Lean

structure TrustedConfig where
  imports : Array Name
  target : Name
  targetId : String
  branch : String
  allowedAxioms : Array Name := #[``propext, ``Quot.sound]
  kernelHeartbeats : Nat := 50000000
  maxDeclarations : Nat := 100000
  maxFileBytes : Nat := 100000000

structure GateError where
  code : String
  message : String
  details : Json := Json.null

abbrev CheckM := Except GateError

def failure {α : Type} (code message : String) (details := Json.null) : CheckM α :=
  .error ⟨code, message, details⟩

def readJson {α : Type} (action : Except String α) : CheckM α :=
  action.mapError fun e => ⟨"INVALID_CERTIFICATE_ENCODING", e, Json.null⟩

def objectFields (j : Json) (fields : Array String) : CheckM Unit := do
  let obj ← readJson j.getObj?
  let keys := obj.fold (fun a k _ => a.push k) (#[] : Array String)
  for key in keys do
    unless fields.contains key do
      failure "INVALID_CERTIFICATE_FIELD" s!"Unexpected field: {key}"
  for key in fields do
    let _ ← readJson (j.getObjVal? key)

def field (j : Json) (key : String) : CheckM Json := readJson (j.getObjVal? key)

def decodeName (j : Json) : CheckM Name := do
  let segments ← readJson j.getArr?
  let mut name := Name.anonymous
  for segment in segments do
    let a ← readJson segment.getArr?
    unless a.size == 2 do failure "INVALID_NAME" "A name segment has two fields"
    let tag ← readJson a[0]!.getStr?
    match tag with
    | "s" => name := .str name (← readJson a[1]!.getStr?)
    | "n" => name := .num name (← readJson a[1]!.getNat?)
    | _ => failure "INVALID_NAME" "Unknown name segment tag"
  return name

def encodeName (name : Name) : Json :=
  Json.arr (go name)
where
  go : Name → Array Json
    | .anonymous => #[]
    | .str p s => (go p).push (Json.arr #[toJson "s", toJson s])
    | .num p n => (go p).push (Json.arr #[toJson "n", toJson n])

partial def decodeLevel (j : Json) : CheckM Level := do
  let a ← readJson j.getArr?
  if a.isEmpty then failure "INVALID_LEVEL" "Empty level"
  let tag ← readJson a[0]!.getStr?
  match tag, a.size with
  | "zero", 1 => return .zero
  | "succ", 2 => return .succ (← decodeLevel a[1]!)
  | "max", 3 => return .max (← decodeLevel a[1]!) (← decodeLevel a[2]!)
  | "imax", 3 => return .imax (← decodeLevel a[1]!) (← decodeLevel a[2]!)
  | "param", 2 => return .param (← decodeName a[1]!)
  | "mvar", _ => failure "OPEN_CERTIFICATE" "Universe metavariables are forbidden"
  | _, _ => failure "INVALID_LEVEL" "Unknown level tag or wrong arity"

def encodeLevel : Level → Json
  | .zero => Json.arr #[toJson "zero"]
  | .succ u => Json.arr #[toJson "succ", encodeLevel u]
  | .max u v => Json.arr #[toJson "max", encodeLevel u, encodeLevel v]
  | .imax u v => Json.arr #[toJson "imax", encodeLevel u, encodeLevel v]
  | .param n => Json.arr #[toJson "param", encodeName n]
  | .mvar n => Json.arr #[toJson "mvar", encodeName n.name]

def decodeBinder (j : Json) : CheckM BinderInfo := do
  match ← readJson j.getStr? with
  | "explicit" => return .default
  | "implicit" => return .implicit
  | "strict_implicit" => return .strictImplicit
  | "instance" => return .instImplicit
  | _ => failure "INVALID_BINDER" "Unknown binder kind"

def encodeBinder : BinderInfo → Json
  | .default => toJson "explicit"
  | .implicit => toJson "implicit"
  | .strictImplicit => toJson "strict_implicit"
  | .instImplicit => toJson "instance"

partial def decodeExpr (j : Json) : CheckM Expr := do
  let a ← readJson j.getArr?
  if a.isEmpty then failure "INVALID_EXPRESSION" "Empty expression"
  let tag ← readJson a[0]!.getStr?
  let e : Expr ← match tag, a.size with
    | "bvar", 2 => return .bvar (← readJson a[1]!.getNat?)
    | "sort", 2 => return .sort (← decodeLevel a[1]!)
    | "const", 3 => do
      let name ← decodeName a[1]!
      let levels ← (← readJson a[2]!.getArr?).mapM decodeLevel
      return .const name levels.toList
    | "app", 3 => return .app (← decodeExpr a[1]!) (← decodeExpr a[2]!)
    | "lam", 5 => return (.lam (← decodeName a[1]!)
        (← decodeExpr a[3]!) (← decodeExpr a[4]!) (← decodeBinder a[2]!))
    | "forall", 5 => return (.forallE (← decodeName a[1]!)
        (← decodeExpr a[3]!) (← decodeExpr a[4]!) (← decodeBinder a[2]!))
    | "let", 6 => return (.letE (← decodeName a[1]!) (← decodeExpr a[2]!)
        (← decodeExpr a[3]!) (← decodeExpr a[4]!) (← readJson a[5]!.getBool?))
    | "nat", 2 => return .lit (.natVal (← readJson a[1]!.getNat?))
    | "string", 2 => return .lit (.strVal (← readJson a[1]!.getStr?))
    | "proj", 4 => return (.proj (← decodeName a[1]!)
        (← readJson a[2]!.getNat?) (← decodeExpr a[3]!))
    | "mdata", 2 => decodeExpr a[1]!
    | "fvar", _ => failure "OPEN_CERTIFICATE" "Free variables are forbidden"
    | "mvar", _ => failure "OPEN_CERTIFICATE" "Expression metavariables are forbidden"
    | _, _ => failure "UNSUPPORTED_CERTIFICATE_FEATURE" "Unknown expression tag or wrong arity"
  let returned := Programme.LeanTorserSyntax.decodeExpr
    (Programme.LeanTorserSyntax.encodeExpr e)
  unless returned == e do
    failure "TORSER_RETURN_FAILURE" "Decoded expression did not return exactly"
  return returned

partial def encodeExpr : Expr → Json
  | .bvar n => Json.arr #[toJson "bvar", toJson n]
  | .fvar n => Json.arr #[toJson "fvar", encodeName n.name]
  | .mvar n => Json.arr #[toJson "mvar", encodeName n.name]
  | .sort u => Json.arr #[toJson "sort", encodeLevel u]
  | .const n us => Json.arr #[toJson "const", encodeName n, Json.arr (us.toArray.map encodeLevel)]
  | .app f x => Json.arr #[toJson "app", encodeExpr f, encodeExpr x]
  | .lam n t b i => Json.arr #[toJson "lam", encodeName n, encodeBinder i, encodeExpr t, encodeExpr b]
  | .forallE n t b i => Json.arr #[toJson "forall", encodeName n, encodeBinder i, encodeExpr t, encodeExpr b]
  | .letE n t v b nd => Json.arr #[toJson "let", encodeName n, encodeExpr t, encodeExpr v, encodeExpr b, toJson nd]
  | .lit (.natVal n) => Json.arr #[toJson "nat", toJson n]
  | .lit (.strVal s) => Json.arr #[toJson "string", toJson s]
  | .mdata _ e => encodeExpr e
  | .proj n i e => Json.arr #[toJson "proj", encodeName n, toJson i, encodeExpr e]

def closed (e : Expr) : Bool := !e.hasFVar && !e.hasMVar && !e.hasLooseBVars

def decodeClosed (j : Json) : CheckM Expr := do
  let e ← decodeExpr j
  unless closed e do failure "OPEN_CERTIFICATE" "A complete expression is not closed"
  return e

def decodeParams (j : Json) : CheckM (List Name) := do
  let names ← (← readJson j.getArr?).mapM decodeName
  let mut seen : NameSet := {}
  for n in names do
    if n.isAnonymous || seen.contains n then
      failure "INVALID_UNIVERSE_PARAMETERS" "Anonymous or repeated universe parameter"
    seen := seen.insert n
  return names.toList

def decodeDeclaration (j : Json) : CheckM Declaration := do
  let kind ← readJson (← field j "kind").getStr?
  if kind == "axiom" then failure "FORBIDDEN_AXIOM" "Candidate axioms are forbidden"
  if kind == "unsafe" || kind == "partial" then
    failure "UNSAFE_DECLARATION" "Unsafe and partial declarations are forbidden"
  if kind == "theorem" || kind == "def" then
    objectFields j #["kind", "name", "level_params", "type", "value"]
    let name ← decodeName (← field j "name")
    if name.isAnonymous then failure "INVALID_NAME" "A declaration name is required"
    let levelParams ← decodeParams (← field j "level_params")
    let type ← decodeClosed (← field j "type")
    let value ← decodeClosed (← field j "value")
    if kind == "theorem" then
      return .thmDecl {name, levelParams, type, value}
    else
      return .defnDecl {name, levelParams, type, value, hints := .regular 0, safety := .safe}
  else if kind == "inductive" then
    objectFields j #["kind", "level_params", "num_params", "types"]
    let levelParams ← decodeParams (← field j "level_params")
    let numParams ← readJson (← field j "num_params").getNat?
    let types ← (← readJson (← field j "types").getArr?).mapM fun t => do
      objectFields t #["name", "type", "ctors"]
      let name ← decodeName (← field t "name")
      let type ← decodeClosed (← field t "type")
      let ctors ← (← readJson (← field t "ctors").getArr?).mapM fun c => do
        objectFields c #["name", "type"]
        let ctorName ← decodeName (← field c "name")
        let ctorType ← decodeClosed (← field c "type")
        return ({name := ctorName, type := ctorType} : Constructor)
      return ({name, type, ctors := ctors.toList} : InductiveType)
    if types.isEmpty then failure "INVALID_INDUCTIVE" "An inductive block is empty"
    return .inductDecl levelParams numParams types.toList false
  else
    failure "UNSUPPORTED_CERTIFICATE_FEATURE" s!"Unsupported declaration kind: {kind}"

def kernelErrorKind : Kernel.Exception → String
  | .unknownConstant _ n => s!"unknown constant {n}"
  | .alreadyDeclared _ n => s!"already declared {n}"
  | .declTypeMismatch .. => "declaration type mismatch"
  | .declHasMVars .. => "declaration contains metavariables"
  | .declHasFVars .. => "declaration contains free variables"
  | .funExpected .. => "function expected"
  | .typeExpected .. => "type expected"
  | .letTypeMismatch .. => "let type mismatch"
  | .exprTypeMismatch .. => "expression type mismatch"
  | .appTypeMismatch .. => "application type mismatch"
  | .invalidProj .. => "invalid projection"
  | .thmTypeIsNotProp .. => "theorem type is not a proposition"
  | .other m => m
  | .deterministicTimeout => "kernel heartbeat limit exceeded"
  | .excessiveMemory => "kernel memory limit exceeded"
  | .deepRecursion => "kernel recursion limit exceeded"
  | .interrupted => "kernel interrupted"

def kernelResult {α : Type} (code : String) (r : Except Kernel.Exception α) : CheckM α :=
  r.mapError fun e => ⟨code, kernelErrorKind e, Json.null⟩

def checkAt (env : Environment) (term type : Expr) : CheckM Unit := do
  let inferred ← kernelResult "KERNEL_REJECTED" (Kernel.check env {} term)
  unless Kernel.isDefEqGuarded env {} inferred type do
    failure "TYPE_MISMATCH" "Kernel-inferred type differs from the expected type"
      (Json.mkObj [("actual_type", encodeExpr inferred), ("expected_type", encodeExpr type)])

structure DependencyReport where
  names : Array Name
  axioms : Array Name
  checkedBodies : Nat

def auditDependencies (env : Environment) (roots allowedAxioms : Array Name) : CheckM DependencyReport := do
  let mut todo := roots
  let mut visited : NameSet := {}
  let mut axioms : NameSet := {}
  let mut checkedBodies := 0
  while !todo.isEmpty do
    let n := todo.back!
    todo := todo.pop
    unless visited.contains n do
      visited := visited.insert n
      let some ci := env.checked.get.find? n
        | failure "UNKNOWN_DEPENDENCY" s!"Unknown dependency: {n}"
      if ci.isUnsafe || ci.isPartial then
        failure "UNSAFE_DEPENDENCY" s!"Unsafe or partial dependency: {n}"
      if ci.isAxiom then
        unless allowedAxioms.contains n do
          failure "FORBIDDEN_AXIOM" s!"Unapproved axiom: {n}"
        axioms := axioms.insert n
      unless closed ci.type do failure "OPEN_DEPENDENCY" s!"Open dependency type: {n}"
      let inferred ← kernelResult "DEPENDENCY_TYPE_REJECTED" (Kernel.check env {} ci.type)
      let sort ← kernelResult "DEPENDENCY_TYPE_REJECTED" (Kernel.whnf env {} inferred)
      unless sort.isSort do failure "DEPENDENCY_TYPE_REJECTED" s!"Dependency type is not a type: {n}"
      if let some body := ci.value? true then
        unless closed body do failure "OPEN_DEPENDENCY" s!"Open dependency body: {n}"
        checkAt env body ci.type
        checkedBodies := checkedBodies + 1
      todo := todo ++ ci.getUsedConstantsAsSet.toArray
  return {names := visited.toArray.qsort Name.lt, axioms := axioms.toArray.qsort Name.lt, checkedBodies}

def levelUsesOnly (allowed : List Name) : Level → Bool
  | .zero => true
  | .succ l => levelUsesOnly allowed l
  | .max l r => levelUsesOnly allowed l && levelUsesOnly allowed r
  | .imax l r => levelUsesOnly allowed l && levelUsesOnly allowed r
  | .param n => allowed.contains n
  | .mvar _ => false

def checkCertificate (cfg : TrustedConfig) (trustedEnv : Environment) (certificate : Json) : CheckM Json := do
  let schema ← readJson (← field certificate "schema").getStr?
  if schema == "programme.kernel-proof-certificate.v1" then
    objectFields certificate #["schema", "target_id", "branch", "root", "declarations"]
  else if schema == "programme.kernel-proof-certificate.v2" then
    objectFields certificate #["schema", "target_id", "branch", "root", "declarations", "root_universe_arguments"]
  else
    failure "UNSUPPORTED_CERTIFICATE_SCHEMA" "Unsupported certificate schema"
  unless (← readJson (← field certificate "target_id").getStr?) == cfg.targetId do
    failure "TARGET_IDENTITY_MISMATCH" "Certificate target ID differs from the fixed slot"
  unless (← readJson (← field certificate "branch").getStr?) == cfg.branch do
    failure "TARGET_BRANCH_MISMATCH" "Certificate branch differs from the fixed target branch"
  let some targetInfo := trustedEnv.checked.get.find? cfg.target
    | failure "TRUSTED_TARGET_UNAVAILABLE" s!"Trusted target not found: {cfg.target}"
  unless targetInfo.isDefinition do
    failure "INVALID_TRUSTED_TARGET" "Expected a trusted definition of the complete proposition"
  let targetLevels := targetInfo.levelParams.map Level.param
  let expected := mkConst cfg.target targetLevels
  checkAt trustedEnv expected (.sort .zero)
  let declarations ← readJson (← field certificate "declarations").getArr?
  if declarations.size > cfg.maxDeclarations then
    failure "CERTIFICATE_LIMIT_EXCEEDED" "Too many declarations"
  let mut env := trustedEnv
  let mut supplied : NameSet := {}
  for declarationData in declarations do
    let declaration ← decodeDeclaration declarationData
    for n in declaration.getNames do
      if supplied.contains n || (trustedEnv.checked.get.find? n).isSome then
        failure "NAME_OVERWRITE_FORBIDDEN" s!"Name already exists: {n}"
      supplied := supplied.insert n
    env ← kernelResult "DECLARATION_REJECTED"
      (env.addDeclCore cfg.kernelHeartbeats.toUSize declaration none true)
  let root ← decodeName (← field certificate "root")
  unless supplied.contains root do
    failure "ROOT_NOT_SUPPLIED" "The root must be a declaration in this certificate"
  let some rootInfo := env.checked.get.find? root
    | failure "ROOT_NOT_FOUND" "The root did not produce a checked declaration"
  let some body := rootInfo.value? true
    | failure "ROOT_BODY_REQUIRED" "The root must have a complete proof body"
  let rootLevels ← if schema == "programme.kernel-proof-certificate.v2" then do
      let arguments ← (← readJson (← field certificate "root_universe_arguments").getArr?).mapM decodeLevel
      unless arguments.size == rootInfo.levelParams.length do
        failure "ROOT_UNIVERSE_ARGUMENT_COUNT" "Each root universe parameter needs its exact level argument"
      unless arguments.all (levelUsesOnly targetInfo.levelParams) do
        failure "UNDECLARED_ROOT_UNIVERSE_PARAMETER" "Root levels may mention only the fixed target's universe parameters"
      pure arguments.toList
    else do
      unless rootInfo.levelParams.length == targetInfo.levelParams.length do
        failure "UNIVERSE_SIGNATURE_MISMATCH" "Supply explicit universe arguments for a polymorphic root specialization"
      pure targetLevels
  let actualType := rootInfo.type.instantiateLevelParams rootInfo.levelParams rootLevels
  let actualBody := body.instantiateLevelParams rootInfo.levelParams rootLevels
  unless Kernel.isDefEqGuarded env {} actualType expected do
    failure "EXACT_TARGET_TYPE_MISMATCH" "The complete root type differs from the fixed target proposition"
      (Json.mkObj [("actual_type", encodeExpr actualType),
        ("expected_type", encodeExpr (targetInfo.value!))])
  checkAt env actualBody expected
  checkAt env (mkConst root rootLevels) expected
  let completedTypeCheck := Json.mkObj [
    ("kernel_checked", toJson true), ("exact_entire_target_type", toJson true),
    ("ordinary_target_binders_preserved", toJson true),
    ("root_universe_arguments", Json.arr (rootLevels.toArray.map encodeLevel)),
    ("root_complete_type", encodeExpr actualType)]
  let annotateFoundationError (e : GateError) : GateError :=
    { e with details := Json.mkObj [
        ("completed_type_check", completedTypeCheck),
        ("dependency_audit_details", e.details)] }
  let targetDependencies ←
    (auditDependencies trustedEnv #[cfg.target] cfg.allowedAxioms).mapError annotateFoundationError
  let dependencies ←
    (auditDependencies env supplied.toArray cfg.allowedAxioms).mapError annotateFoundationError
  return Json.mkObj [
    ("status", toJson "PASS"), ("target_id", toJson cfg.targetId),
    ("branch", toJson cfg.branch), ("target_declaration", encodeName cfg.target),
    ("root", encodeName root), ("target_complete_type", encodeExpr (targetInfo.value!)),
    ("root_universe_arguments", Json.arr (rootLevels.toArray.map encodeLevel)),
    ("root_complete_type", encodeExpr actualType),
    ("root_complete_body", encodeExpr actualBody),
    ("kernel_checked", toJson true), ("exact_entire_target_type", toJson true),
    ("ordinary_target_binders_preserved", toJson true),
    ("candidate_code_executed", toJson false), ("candidate_imports_loaded", toJson false),
    ("torser_structural_return_checked", toJson true),
    ("supplied_declarations", toJson supplied.size),
    ("dependency_count", toJson dependencies.names.size),
    ("dependency_bodies_rechecked", toJson dependencies.checkedBodies),
    ("target_dependency_count", toJson targetDependencies.names.size),
    ("axioms", toJson (dependencies.axioms.map Name.toString))]

def errorJson (cfg : TrustedConfig) (e : GateError) : Json := Json.mkObj [
  ("status", toJson "REJECTED"), ("target_id", toJson cfg.targetId),
  ("branch", toJson cfg.branch), ("reason", toJson e.code),
  ("message", toJson e.message), ("details", e.details),
  ("candidate_code_executed", toJson false), ("candidate_imports_loaded", toJson false)]

def mainFor (cfg : TrustedConfig) (args : List String) : IO UInt32 := do
  let result ← try
    unless args.length == 1 do
      throw (IO.userError "Expected exactly one private JSON certificate path")
    let raw ← IO.FS.readFile args[0]!
    if raw.utf8ByteSize > cfg.maxFileBytes then
      pure <| failure "CERTIFICATE_LIMIT_EXCEEDED" "Certificate file is too large"
    else
      match Json.parse raw with
      | .error e => pure <| failure "INVALID_JSON" e
      | .ok certificate =>
        initSearchPath (← getBuildDir)
        let env ← importModules (cfg.imports.map fun n => ({module := n} : Import))
          {} (trustLevel := 0) (plugins := #[]) (loadExts := false)
        pure <| checkCertificate cfg env certificate
  catch e =>
    pure <| failure "CHECKER_ENVIRONMENT_ERROR" e.toString
  match result with
  | .ok report => IO.println report.compress; return 0
  | .error e => IO.println (errorJson cfg e).compress; return 1

end Programme.DataProofGate
