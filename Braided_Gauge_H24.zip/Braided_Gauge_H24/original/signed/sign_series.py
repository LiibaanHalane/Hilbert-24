"""Formal binomial-series identity and actual T-polynomial projector prefixes.
Norm convergence follows from the physical bound in PROOF.md, not from 2-adic addresses."""
from native_polynomial import *
from native_coefficients import ops
from pathlib import Path
import json
p=Path(__file__).parent; checks=[]; prefixes=[]
A=T.scale(2)-ONE; M=(T*(ONE-T)).scale(4)
for N in (1,2,4,8):
 # First prove formal power-series identity modulo z^N, with z the formal M variable.
 S=ZERO
 for k in range(N): S=S+(T**k).scale(F(comb(2*k,k),4**k))
 error=(ONE-T)*S*S-ONE
 assert all(k>=N for k in error.coeff); checks.append('formal_binomial_inverse_square_mod_'+str(N))
 # Evaluate on the original transfer polynomial.
 SM=ZERO
 for k in range(N): SM=SM+(M**k).scale(F(comb(2*k,k),4**k))
 PN=(ONE+A*SM).scale(F(1,2)); assert PN.dagger()==PN;checks.append('physical_prefix_selfadjoint_'+str(N))
 eval_one=ZERO
 for c in PN.coeff.values(): eval_one=eval_one+Poly({0:c})
 assert eval_one==ONE;checks.append('physical_vacuum_fixed_'+str(N))
 prefixes.append({'N':N,'P_N':PN.encoded()})
(p/'sign_receipt.json').write_text(json.dumps({'checks':checks,'operations':len(ops),'prefixes':prefixes,'norm_scope':'conditional physical norm bound ||M||<=r<1, no real convergence inferred from dyadic chart'},indent=2))
print('sign series identities',len(checks),'native operations',len(ops))
