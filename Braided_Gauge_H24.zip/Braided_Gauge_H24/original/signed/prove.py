"""Check exact scalar obligations of the signed spectral transit.
Analytic theorems and their hypotheses are in PROOF.md, not asserted as SMT facts.
"""
import ctypes as C, json, hashlib
from pathlib import Path
p=Path(__file__).parent; out=p/'smt'; out.mkdir(exist_ok=True)
z=C.CDLL('libz3.so.4'); ptr=C.c_void_p
for name,r,a in [('Z3_mk_config',ptr,[]),('Z3_mk_context',ptr,[ptr]),('Z3_eval_smtlib2_string',C.c_char_p,[ptr,C.c_char_p]),('Z3_del_context',None,[ptr]),('Z3_del_config',None,[ptr]),('Z3_get_full_version',C.c_char_p,[])]:
 f=getattr(z,name);f.restype=r;f.argtypes=a
rows=[]
def run(name,vs,guard,goal,expected='unsat',logic='QF_NRA'):
 text='(set-option :timeout 10000)\n(set-logic '+logic+')\n'+''.join(f'(declare-const {v} Real)\n' for v in vs.split())+f'(assert {guard})\n(assert (not {goal}))\n(check-sat)\n'
 (out/(name+'.smt2')).write_text(text); c=z.Z3_mk_config(); x=z.Z3_mk_context(c);z.Z3_del_config(c)
 val=z.Z3_eval_smtlib2_string(x,text.encode()).decode();z.Z3_del_context(x)
 (out/(name+'.log')).write_text(val); res=val.splitlines()[0]
 rows.append(dict(name=name,result=res,expected=expected,sha256=hashlib.sha256(text.encode()).hexdigest()))
 assert res==expected,(name,val);print(name,res,flush=True)
# A=2T-I, M=I-A^2.
run('matched_square','t','true','(= (* 4 t (- 1 t)) (- 1 (* (- (* 2 t) 1) (- (* 2 t) 1))))')
run('matched_positive_contraction','t','(and (<= 0 t) (<= t 1))','(and (<= 0 (* 4 t (- 1 t))) (<= (* 4 t (- 1 t)) 1))')
run('matched_exact_peak','t','(= (* 4 t (- 1 t)) 1)','(= t (/ 1 2))')
run('direct_heat_to_matched','t q','(and (<= 0 t) (<= t q) (<= 0 q) (< q (/ 1 2)))','(and (<= (* 4 t (- 1 t)) (* 4 q (- 1 q))) (< (* 4 q (- 1 q)) 1))')
run('matched_square_lower','m a r','(and (= m (- 1 (* a a))) (<= m r) (<= 0 r) (< r 1))','(>= (* a a) (- 1 r))')
# Recurrence on same polynomial variable; no actual continuum input invented.
run('green_parametrix_induction','a m p s','(and (= m (- 1 (* a a))) (= (* (* a a) s) (- 1 p)))','(= (* (* a a) (+ s (* p s))) (- 1 (* p p)))')
run('green_residual_positive','r','(and (<= 0 r) (< r 1))','(and (<= 0 (* r r)) (< (* r r) 1))')
run('parametrix_margin','b e d','(and (>= b 0) (>= e 0) (<= d 1) (< d 1) (< (* b e) (- 1 d)))','(> (- 1 (* b e)) d)')
run('parametrix_explicit_radius','b r eps','(and (>= b 0) (<= 0 r) (< r 1) (= (* 2 (+ 1 b) eps) (- 1 r)))','(and (> eps 0) (< (* b eps) (- 1 r)))')
run('direct_parametrix_strict','t q','(and (<= 0 t) (<= t q) (<= 0 q) (< q (/ 1 2)))','(and (<= (* 2 t) (* 2 q)) (< (* 2 q) 1))')
# One-tolerance MG25 route, exact rational endpoints (q=1/2, eps=3/64).
run('MG25_polynomial','t','true','(= (+ (* (- 1 t) (- (/ 1 2) t)) (/ 3 64)) (* (- t (/ 5 8)) (- t (/ 7 8))))')
run('MG25_open_band','t','(and (< (/ 5 8) t) (< t (/ 7 8)))','(< (+ (* (- 1 t) (- (/ 1 2) t)) (/ 3 64)) 0)')
run('MG25_strict_tolerance','q eps','(and (< 0 q) (< q 1) (<= 0 eps) (< (* 4 eps) (* (- 1 q) (- 1 q))))','(> (- (* (- 1 q) (- 1 q)) (* 4 eps)) 0)')
# Block and Stokes sources reuse their original guards.
run('NB_floor_pivots','g d k eta','(and (> g 0) (> d 0) (>= k 0) (< (* k k) (* g d)) (= (* eta (+ g d)) (- (* g d) (* k k))))','(and (> eta 0) (> (- g eta) 0) (> (- d eta) 0))')
run('NB_floor_square','g d k eta x y','(= (* eta (+ g d)) (- (* g d) (* k k)))','(= (* (- g eta) (- (+ (* g x x) (* d y y)) (* 2 k x y) (* eta (+ (* x x) (* y y))))) (+ (* (- (* (- g eta) x) (* k y)) (- (* (- g eta) x) (* k y))) (* eta eta y y)))')
run('Stokes_floor','c h n R','(and (> c 0) (= (* c h) (+ n R)) (>= R 0))','(>= (* c h) n)')
run('Green_two_step','t q','(and (<= 0 t) (<= t q) (<= 0 q) (< q 1))','(and (<= (+ 1 t) (+ 1 q)) (< (+ 1 q) 2))')
run('finite_mass_return','e d','(and (> e 0) (not (and (> e 0) (< e d))))','(<= d e)')
# Countermodel only to generic algebraic inference, not original YM.
run('no_strict_norm_from_matched_identity','t','(= t (/ 1 2))','(< (* 4 t (- 1 t)) 1)','sat')
# Check signed proof transport on propositional rails, no explosion.
def boolean(name,decl,guard,goal):
 text='(set-logic QF_UF)\n'+''.join(f'(declare-const {v} Bool)\n' for v in decl.split())+f'(assert {guard})\n(assert (not {goal}))\n(check-sat)\n'
 (out/(name+'.smt2')).write_text(text);c=z.Z3_mk_config();x=z.Z3_mk_context(c);z.Z3_del_config(c);val=z.Z3_eval_smtlib2_string(x,text.encode()).decode();z.Z3_del_context(x);(out/(name+'.log')).write_text(val)
 res=val.splitlines()[0];assert res=='unsat';rows.append(dict(name=name,result=res,expected='unsat',sha256=hashlib.sha256(text.encode()).hexdigest()));print(name,res)
boolean('signed_positive_covariance','p q','(and p (=> p q))','q')
boolean('signed_negative_contravariance','p q','(and (=> p q) (not q))','(not p)')
# The two *report* coordinates independent; unrelated positive evidence not inferred.
boolean('both_reports_no_unrelated_positive','p n x','(and p n (not x))','(not x)')
(p/'prover_receipt.json').write_text(json.dumps({'prover':z.Z3_get_full_version().decode(),'scope':'scalar and propositional implications; mathematical operator/covariance proof separate','results':rows},indent=2))
print('summary',{v:sum(r['result']==v for r in rows) for v in ['unsat','sat','unknown']})
