"""Native polynomial operations on the actual symbolic operator T. Reuse the
prior normalized coefficient chart; formal polynomial marks are not discarded."""
from native_polynomial import *
from native_coefficients import E, F, ops
import json
from pathlib import Path
p=Path(__file__).parent
checks=[]
def ck(name,a,b):
 assert a==b,(name,a.raw(),b.raw());checks.append(name)
A=T.scale(2)-ONE; M=(T*(ONE-T)).scale(4)
ck('matched_Gdagger',M,ONE-A.dagger()*A)
ck('self_adjoint',A.dagger(),A); ck('M_self_adjoint',M.dagger(),M)
# Exact original Green fold in the M variable, rather than a new numerical H.
L=Poly({0:E.make((1,0,0,1,0,1))})+Poly({i:E.make((0,0,c.vals()[0],0,0,0)) for i,c in M.coeff.items()})
fold=[]
for j in range(5):
 N=2**j; L_N=L**N; P=L_N.extract(2); S=L_N.extract(3); B=A*S
 ck('power_'+str(N),P,M**N)
 ck('parametrix_'+str(N),ONE-B*A,P)
 ck('left_right_'+str(N),B*A,A*B)
 ck('self_adjoint_parametrix_'+str(N),B.dagger(),B)
 fold.append(dict(N=N,parametrix=B.encoded(),residual=P.encoded()))
# q=1/2, eps=3/64, exactly archived MG25 polynomial window.
ck('MG25_factor',(ONE-T)*(ONE.scale(F(1,2))-T)+ONE.scale(F(3,64)),(T-ONE.scale(F(5,8)))*(T-ONE.scale(F(7,8))))
# Source moment partition (the actual 16-effect interpretation).
for j in range(3):
 acc=ZERO
 for k in range(5):acc=acc+((T**k)*((ONE-T)**(4-k))*(M**j)).scale(comb(4,k))
 ck('split_preserves_M_power_'+str(j),acc,M**j)
(p/'native_receipt.json').write_text(json.dumps({'operator':'T=exp(-tau H_phys), formal operator, all original marks retained','checks':checks,'operations':{o:ops.count(o) for o in sorted(set(ops))},'fold':fold},indent=2))
print('native identities',len(checks),'operations',len(ops))
