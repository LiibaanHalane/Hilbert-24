"""Finite proof-transit grammar, with the source's additive rule charge.
This is a Python realization of min-plus proof-tree evaluation, NOT a Lean
kernel or the original physical correlation evaluator. Hypotheses are
explicit typed proof leaves; source assumptions are never auto-inhabited.
All cycles have positive charge; the least finite-proof solution is obtained
by height induction, retaining all tied minimum productions.
"""
from dataclasses import dataclass, asdict
from itertools import product
from collections import defaultdict
from pathlib import Path
import json
@dataclass(frozen=True)
class Rule:
    name:str; head:str; tail:tuple; source:str; charge:int=1
# Fixed one physical fibre and lag; 'gap' and 'some_window' existential.
# Signs of claims refer to logical proof types, not truth-flag negation.
R=[]
def r(name,head,tail,source): R.append(Rule(name,head,tuple(tail.split()),source))
r('NBPhysicalBlockReturns','floor+', 'block_budget+', 'NBPhysicalBlockReturns: original coarse/fine three form bounds, eta=(gamma*delta-kappa^2)/(gamma+delta)')
r('floorFromStokes','floor+', 'stokes_square+', 'YM_Exact_Comorphism_Continuation.lean: floorFromStokes, d=1/c')
r('floorFromSchur','floor+', 'schur_blocks+', 'YM_Exact_Comorphism_Continuation.lean: floorFromSchur')
r('gapFromFloor','gap+', 'floor+ spectral_core+', 'YM_Exact_Comorphism_Continuation.lean: gapFromFloor')
r('heat_cap_return','gap+', 'heat_cap+ spectral_core+', 'dense_heat_form_return; physical heat spectral calculus')
r('dyadic_return','gap+', 'dyadic_cap+ spectral_core+', 'Physical_Green_Return.md; spectral calculus')
r('green_return','gap+', 'green_cap+ spectral_core+', 'Physical_Green_Return.md, finite N,c<N')
r('MG24','gap+', 'compact_negative_defect+ covariance+', 'Self_Adjoint_Witness.proof.txt: 5.2')
r('MG25','gap+', 'one_anchor_test+ covariance+', 'YM_Exact_Source_Names_and_Alternatives.md MG25; original one-tolerance discriminant theorem')
r('MG32','gap+', 'principal_disk+ spectral_core+', 'BAPPrincipalMixtureReturns: positive mixture, principal germ and exact mass edge')
r('MG50','gap+', 'completed_section_bound+ spectral_core+', 'Recovered_Mass_Gap_Proofs MG50 (complete-section bound, not just wordwise)')
r('parametrix_to_matched','matched+', 'parametrix+ covariance+', 'PROOF.md theorem 2, finite rank removal')
r('matched_to_parametrix','parametrix+', 'matched+', 'PROOF.md theorem 2, B=A sum M^j')
r('matched_to_window','window+', 'matched+ covariance+', 'PROOF.md theorem 1, upward spectral support')
r('window_to_gap','gap+', 'window+', 'PROOF.md theorem 1')
r('gap_to_some_window','some_window+', 'gap+ spectral_core+', 'PROOF.md theorem 3, choose dyadic physical lag from positive bound')
r('window_to_some_window','some_window+', 'window+', 'existential introduction at the same lag')
r('construct_clopen_projector','clopen+', 'some_window+ spectral_core+', 'PROOF.md theorem 3, sign(A) with binomial series')
r('finish','original_YM+', 'clopen+ original_fields+ positive_excitation+', 'YM_Exact_Comorphism_Continuation.lean: finish/fullTargetToOriginal; original clauses retained')
# Negative transit only where the reverse of a positive implication is valid.
r('low_point_to_window_refutation','window-', 'low_point+ covariance+', 'PROOF.md theorem 4, boost to window peak')
r('window_refutes_matched','matched-', 'window- covariance+', 'contravariance of matched_to_window')
r('matched_refutes_parametrix','parametrix-', 'matched- covariance+', 'contravariance of parametrix_to_matched')
r('parametrix_refutes_matched','matched-', 'parametrix-', 'contravariance of matched_to_parametrix')
r('low_family_to_gap_refutation','gap-', 'low_family+', 'for each positive proposed gap, its original low-energy challenge')
r('gap_refutes_some_window','some_window-', 'gap-', 'contravariance of some-window to gap; existential elimination')
r('gap_refutes_clopen','clopen-', 'gap-', 'contravariance of clopen -> gap')
r('clopen_refutes_original','original_YM-', 'clopen-', 'ONLY this marked physical candidate, not all phases of its group')
# A direct known spectral source, requiring stronger cap q<1/2 at fixed lag.
r('half_cap_to_matched','matched+', 'half_cap+', 'PROOF.md scalar monotonicity on [0,1/2); vacuum M=0')
J=sorted({r.head for r in R}|{x for r in R for x in r.tail})
def fold(mark,seeds):
  # seed name -> evidence record, never a bare truth bit
  rules=R+[Rule('leaf:'+s,s,(),str(data),0) for s,data in seeds.items()]
  by=defaultdict(list)
  for rule in rules: by[rule.head].append(rule)
  V={j:None for j in J}; tight={j:[] for j in J}; rounds=0
  # height |J| bound follows from strict positivity of internal rule cost:
  # minimum tree cannot repeat a vertex on a branch (subtree substitution).
  for k in range(len(J)+1):
    W={}; choices={}
    for j in J:
      candidates=[(rule.charge+sum(V[x] for x in rule.tail),rule) for rule in by[j] if all(V[x] is not None for x in rule.tail)]
      best=min((c for c,_ in candidates),default=None)
      W[j]=best;choices[j]=[r for c,r in candidates if c==best]
    rounds+=1
    if W==V: tight=choices;break
    V=W;tight=choices
  else: raise AssertionError('height bound violated')
  def term(j):
    if V[j] is None:return None
    t=tight[j][0]
    return {'judgment':j,'physical_mark':mark,'cost':V[j],'rule':t.name,'source':t.source,'children':[term(x) for x in t.tail]}
  # H24 local calibration on every productive rule.
  slack=[]
  for r in rules:
    if V[r.head] is not None and all(V[x] is not None for x in r.tail):
      s=r.charge+sum(V[x] for x in r.tail)-V[r.head]; assert s>=0
      slack.append({'rule':r.name,'slack':s})
  def validate(t):
    if t is None:return
    rule=next(r for r in by[t['judgment']] if r.name==t['rule'])
    assert t['physical_mark']==mark and tuple(c['judgment'] for c in t['children'])==rule.tail
    for c in t['children']:validate(c)
    assert t['cost']==rule.charge+sum(c['cost'] for c in t['children'])==V[t['judgment']]
  targets={j:term(j) for j in ['gap+','gap-','window+','window-','matched+','matched-','parametrix+','parametrix-','clopen+','clopen-','original_YM+','original_YM-']}
  for t in targets.values():validate(t)
  return {'mark':mark,'leaf_evidence':seeds,'rounds':rounds,'grade':'unit production charge; not measured bit steps','potential':V,'tight_productions':{j:[r.name for r in tight[j]] for j in J},'slack':slack,'targets':targets,'status':{j:('derived in this grammar' if V[j] is not None else 'no finite derivation in this grammar') for j in J}}
# Actual mathematical hypotheses, as abstract context, not fabricated proofs of them.
ctx={'covariance+':'HYP: strongly continuous positive-energy Poincare representation of this physical fibre','spectral_core+':'HYP: same-H spectral theorem and physical domain/word realization','original_fields+':'HYP: all original construction/acceptance fields of this one phase','positive_excitation+':'HYP: same-H finite positive spectral witness'}
results={}
results['original_requirements_context']=fold('arbitrary-G:original-continuum:one-marked-phase',ctx)
assert results['original_requirements_context']['targets']['original_YM+'] is None
assert results['original_requirements_context']['targets']['original_YM-'] is None
# For each known supplier theorem, emit a lambda-proof schema and its minimal path.
leaves={
 'block_budget+':'HYP: original NBStrictBlockBudget + NBSplitFor',
 'stokes_square+':'HYP: actual B,C,R,c with physical energy_read, CB=I, dagger_sum',
 'schur_blocks+':'HYP: original block forms, D inverse, same-source norm/energy, gamma,k',
 'heat_cap+':'HYP: full original heat form cap with one q<1',
 'dyadic_cap+':'HYP: one physical dyadic power cap on Q',
 'green_cap+':'HYP: original Green sum cap c<N',
 'compact_negative_defect+':'HYP: actual original N_q compact',
 'one_anchor_test+':'HYP: actual original MG25 finite-tolerance form bound; strict discriminant',
 'principal_disk+':'HYP: original positive mixture and principal holomorphic disk',
 'completed_section_bound+':'HYP: MG50 estimate on every completed physical section',
 'parametrix+':'HYP: actual bounded B, finite-rank K, ||I-BA-K||<=r<1',
 'matched+':'HYP: actual ||M_tau||<=r<1',
 'half_cap+':'HYP: ||T Q||<=q<1/2 at this physical lag'}
for leaf,data in leaves.items():
 results['schema:'+leaf]=fold('arbitrary-G:original-continuum:one-marked-phase',{**ctx,leaf:data})
 assert results['schema:'+leaf]['targets']['original_YM+'] is not None
# Install all authenticated alternative supplier hypotheses simultaneously in a schema.
results['schema:all_alternatives']=fold('arbitrary-G:original-continuum:one-marked-phase',{**ctx,**leaves})
assert results['schema:all_alternatives']['targets']['original_YM+'] is not None
assert len(results['schema:all_alternatives']['tight_productions']['gap+'])>1
# Test the actual logic with standard positive-energy representations (NOT YM).
# H=0⊕sqrt(|p|²+m²), unitary massive scalar one-particle rep, m=log4/tau.
results['massive_model']=fold('control:vacuum+massive-scalar-one-particle',{'covariance+':'standard scalar Poincare representation on invariant mass-shell L2','spectral_core+':'multiplication spectral theorem; full form domain','half_cap+':'m=log(4)/tau, E(p)>=m -> exp(-tau E(p))<=1/4'})
assert results['massive_model']['targets']['clopen+'] is not None and results['massive_model']['targets']['original_YM+'] is None
# H=0⊕|p| on massless positive-energy shell. For every E>0 choose p of that size.
results['massless_model']=fold('control:vacuum+massless-scalar-one-particle',{'covariance+':'standard massless scalar Poincare representation','spectral_core+':'multiplication spectral theorem','low_point+':'positive massless momentum of energy log(2)/tau','low_family+':'every proposed positive mass d has spectral point E=d/2'})
assert results['massless_model']['targets']['parametrix-'] is not None and results['massless_model']['targets']['clopen-'] is not None
# Check that the archive root has not been equated with a proof schema.
assert results['massless_model']['targets']['original_YM+'] is None
# BOTH is a report-layer value, not a kernel proof of contradiction.
reports=[('candidate-1','positive'),('candidate-2','negative')]
report_summary={'reports':reports,'occupancy':[1,1],'unrelated_inferred':False,'verified_contradiction':False}
out={'rules':[asdict(r) for r in R],'results':results,'report_test':report_summary,'analytic_scope':'conditional theorem schemas and stated standard control models; no all-group continuum input evaluated; no proof of its nonexistence'}
Path(__file__).with_name('fold_receipt.json').write_text(json.dumps(out,indent=2))
print('rules',len(R),'judgments',len(J),'conditional complete routes',len(leaves))
print('original candidate in requirements context: neither (not a global refutation)')
print('massive control: clopen+',results['massive_model']['potential']['clopen+'])
print('massless control: clopen-',results['massless_model']['potential']['clopen-'])
print('each conditional route returns original certificate as proof term with explicit hypotheses')
