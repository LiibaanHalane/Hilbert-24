#!/usr/bin/env python3
"""Recovered exact rational coefficient chart, without the scalar H_G initializer."""
from fractions import Fraction as F
from math import gcd,isqrt,lcm
import json
from pathlib import Path
from dataclasses import dataclass
from functools import lru_cache
M=1<<64
ap=64
# Integral D on the native lanes; derives from G^{-1}rho(x)^t G.
# For the middle block use H2^-1 B^t H2; inverse 3 exists at this cut.
def add(x,y):return tuple((a+b)%M for a,b in zip(x,y))
def scale(k,x):return tuple(k*a%M for a in x)
def U(x):return (*x[1:],x[0])
def D(x):
 t,b,p,h,r,k=x
 # B^t H2 = [[2p-r,-p+2r],[2h-k,-h+2k]]
 z=pow(3,-1,M)
 return (t,b,z*(4*p-2*r+2*h-k)%M,z*(-2*p+4*r-h+2*k)%M,z*(2*p-r+4*h-2*k)%M,z*(-p+2*r-2*h+4*k)%M)
@lru_cache(maxsize=None)
def tau(u):return sum(pow(4,j,M)*(-1)**j*pow(u,2*j+1,M)*pow((2*j+1)**2,-1,M) for j in range(ap//2))%M
@lru_cache(maxsize=None)
def ti(y):
 u=y
 for _ in range(ap//2):u=(y+u-tau(u))%M
 assert tau(u)==y;return u
@lru_cache(maxsize=None)
def enc(x):
 x=tuple(tau(u%M) for u in x);s=(0,)*6;z=x
 for j in range(6):s=add(s,scale(2**j,z));z=U(z)
 u=scale(-pow(63,-1,M),s)
 return scale(-pow(3,-1,M),add(u,scale(2,D(u))))
@lru_cache(maxsize=None)
def dec(x):
 u=add(x,scale(-2,D(x)));v=add(u,scale(-2,U(u)));return tuple(ti(a) for a in v)
def prod(x,y):
 t,b,p,h,r,k=x;u,d,a,e,f,g=y
 return tuple(z%M for z in (t*u,t*d+b*u-2*b*d,p*a+h*f,p*e+h*g,r*a+k*f,r*e+k*g))
def signed(x):return x if x<M//2 else x-M
ops=[]
@dataclass(frozen=True)
class E:
 c:tuple
 den:int
 @staticmethod
 def make(vals):
  v=tuple(F(x) for x in vals);d=lcm(*(x.denominator for x in v));num=tuple(int(x*d) for x in v);return E._int(num,d)
 @staticmethod
 def _int(num,d):
  if d<0:d=-d;num=tuple(-x for x in num)
  g=gcd(d,*num);d//=g;num=tuple(x//g for x in num)
  assert max(map(abs,num))<M//2
  r=E(enc(tuple(x%M for x in num)),d);assert r.num()==num;return r
 def num(self):return tuple(signed(x) for x in dec(self.c))
 def vals(self):return tuple(F(x,self.den) for x in self.num())
 def __add__(self,o):
  a,b=self.num(),o.num();assert max(abs(x)*o.den+abs(y)*self.den for x,y in zip(a,b))<M//2
  ops.append('add');return E._int(tuple(signed(x) for x in add(scale(o.den,dec(self.c)),scale(self.den,dec(o.c)))),self.den*o.den)
 def __neg__(self):return self.scal(-1)
 def __sub__(self,o):return self+(-o)
 def scal(self,k):
  k=F(k);a=self.num();assert max(abs(x*k.numerator) for x in a)<M//2
  ops.append('scale');return E._int(tuple(signed(x) for x in scale(k.numerator,dec(self.c))),self.den*k.denominator)
 def __mul__(self,o):
  assert 4*max(map(abs,self.num()))*max(map(abs,o.num()))<M//2
  ops.append('product');return E._int(tuple(signed(x) for x in prod(dec(self.c),dec(o.c))),self.den*o.den)
 def dagger(self):
  # D may have denominator 3; retain it explicitly so signed readback is exact.
  assert 12*max(map(abs,self.num()))<M//2
  ops.append('dagger');return E._int(tuple(signed(x) for x in scale(3,D(dec(self.c)))),3*self.den)
 def __eq__(self,o):return isinstance(o,E) and self.vals()==o.vals()
 def addresses(self):
  def a(x):
   x%=M;y=x;bits=[]
   for _ in range(ap):e=y%2;bits.append(e);y=(3*y+e)//2
   c=sum(2**j*3**(ap-1-j)*e for j,e in enumerate(bits));assert -c*pow(3**ap,-1,M)%M==x
   return M-1+x
  return [a(x) for x in self.c]
