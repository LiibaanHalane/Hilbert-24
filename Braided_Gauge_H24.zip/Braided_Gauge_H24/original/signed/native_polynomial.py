#!/usr/bin/env python3
"""Exact native H24 on Q[T_phys], the polynomial subalgebra of the ORIGINAL
heat operator T_phys=exp(-tau H_phys)|QH. No numerical H or heat eigenvalues
are assigned. The original coefficient chart is applied to polynomial
coefficients with degree/operator/phase/lag marks retained. It is not a
2-adic analytic power series of a complex Hilbert-space operator.
All actual native products use the recovered six-lane transported product.
"""
from native_coefficients import E, F, ops
from dataclasses import dataclass
from math import comb
from itertools import product
from pathlib import Path
import json, hashlib
p=Path(__file__).resolve().parent
z=E.make((0,)*6); ident=E.make((1,0,1,0,0,1))
@dataclass
class Poly:
    coeff: dict
    def __post_init__(self):
        self.coeff={int(k):v for k,v in self.coeff.items() if v!=z}
    def __add__(self,b):
        return Poly({k:self.coeff.get(k,z)+b.coeff.get(k,z) for k in self.coeff.keys()|b.coeff.keys()})
    def __neg__(self):return self.scale(-1)
    def __sub__(self,b):return self+(-b)
    def scale(self,r):return Poly({k:v.scal(F(r)) for k,v in self.coeff.items()})
    def __mul__(self,b):
        c={}
        for i,a in self.coeff.items():
            for j,v in b.coeff.items():c[i+j]=c.get(i+j,z)+a*v
        return Poly(c)
    def __pow__(self,k):
        assert k>=0
        a=ONE;b=self
        while k:
            if k&1:a=a*b
            k//=2
            if k:b=b*b
        return a
    def dagger(self):return Poly({k:v.dagger() for k,v in self.coeff.items()})
    def extract(self,idx):return Poly({k:ident.scal(v.vals()[idx]) for k,v in self.coeff.items()})
    def raw(self):return {str(k):list(map(str,v.vals())) for k,v in sorted(self.coeff.items())}
    def encoded(self):return {str(k):{'lanes':list(map(str,v.vals())),'denominator':v.den,'normalized_lanes':list(v.c),'Godel_addresses':v.addresses()} for k,v in sorted(self.coeff.items())}
ZERO=Poly({});ONE=Poly({0:ident});T=Poly({1:ident});B=ONE-T
