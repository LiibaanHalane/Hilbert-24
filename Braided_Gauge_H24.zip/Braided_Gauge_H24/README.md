# Braided gauge H24 continuation

Read paper.pdf, then wire.py and gauge_exact.py. This is wiring on the recovered original YM signed H24 and canonical cylinder components, not a replacement SAT/continuum solver. The older central `hilbert24.py` CLI and the dependency closure of `canonical_torser.py` were not recovered in executable form in this pass. The six-strand operation is the exact archived formula applied to the recovered native coefficient class. The full signed source terms are conditional, not accepted all-group physical certificates. The new Cartan and sharp focusing boundary-minimum proofs are written mathematical theorems; the latter is on the specified classical boundary path fibre. The ordered quantum field product remains the original form. The formal Hets/Lean/Agda algebraic ports are source only, no kernel available. No physical time or work is assumed in the canonical interpretation.

Reproduction (Python 3, SymPy, system libz3.so.4):

```
python original/signed/signed_fold.py
python original/signed/native_transit.py
python original/signed/sign_series.py
python original/signed/prove.py
python original/canonical/test_canonical.py
python gauge_exact.py
python wire.py
python code_ports.py
```

The original source scripts have been copied unchanged from the retrieved archives. `wire.py` invokes the original engine and native coefficient operations, attaches the original prefix and braid equations and the four new theorem ports, and retains the original hypothesis fields. `braided_strands.json` carries six conditional terms, their ternary controls with marked padding, canonical control AND full-source addresses, all four Golay code families, and the symbolic native operator seeds/returns. `gauge_port_codes.json` protects the new written proof bodies through the same quotation grammar. `gauge_exact_receipt.json` verifies exact classical Cartan and free associative Jacobi identities. `braided_receipt.json` records the executed returns. The original SMT and numerical-free checks are retained under original/signed.
