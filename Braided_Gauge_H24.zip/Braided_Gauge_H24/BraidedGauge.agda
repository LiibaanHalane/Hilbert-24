{-# OPTIONS --safe --without-K #-}
module BraidedGauge where
open import Agda.Builtin.Equality
infixr 4 _∙_
record Group : Set₁ where
  field
    G : Set
    e : G
    _∙_ : G → G → G
    inv : G → G
    assoc : (a b c : G) → (a ∙ b) ∙ c ≡ a ∙ (b ∙ c)
    idL : (a : G) → e ∙ a ≡ a
    idR : (a : G) → a ∙ e ≡ a
    invL : (a : G) → inv a ∙ a ≡ e
    invR : (a : G) → a ∙ inv a ≡ e
sym : {A : Set} {a b : A} → a ≡ b → b ≡ a
sym refl = refl
trans : {A : Set} {a b c : A} → a ≡ b → b ≡ c → a ≡ c
trans refl q = q
cong : {A B : Set} (f : A → B) {a b : A} → a ≡ b → f a ≡ f b
cong f refl = refl
module Return (g : Group) where
  open Group g
  hurwitz-product : (a b : G) → b ∙ (inv b ∙ (a ∙ b)) ≡ a ∙ b
  hurwitz-product a b = trans (sym (assoc b (inv b) (a ∙ b)))
    (trans (cong (λ t → t ∙ (a ∙ b)) (invR b)) (idL (a ∙ b)))
  holonomy-correction : (h t : G) → (t ∙ (inv t ∙ (h ∙ t))) ∙ inv t ≡ h
  holonomy-correction h t = trans (cong (λ q → q ∙ inv t) (hurwitz-product h t))
    (trans (assoc h t (inv t)) (trans (cong (λ q → h ∙ q) (invR t)) (idR h)))
