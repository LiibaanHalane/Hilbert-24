from pathlib import Path
import runpy,json,hashlib
P=Path(__file__).parent
old=runpy.run_path(str(P/'original/nullcone/check.py'))
s=(P/'paper.tex').read_text()
sections=[('BG-CARTAN','The original conformal metric is a gauge packet','A sharp original boundary-dependent focusing minimum','Smooth original det-one positive transverse metric; retained SO(2) frame','F_A=-P wedge P; D_A P=0; exact gauge covariance and shear metric',[]),('BG-MIN','A sharp original boundary-dependent focusing minimum','Braided prefixes: one group proof, one first-passage proof','BG-CARTAN; 0<epsilon<v; fixed positive det-one endpoint metrics; all smooth paths','Xi minimum = d^2/(4 log(v/epsilon)); explicit attaining exponential path',['BG-CARTAN']),('BG-BRAID','Braided prefixes: one group proof, one first-passage proof','The full normalized six-strand operator return','Original six marked labels; group laws; exact prefix drift grammar','First passage and holonomy-corrected Hurwitz return',[]),('BG-GUARD','The full normalized six-strand operator return','Actual proof terms and canonical codes','Involutive Gram dagger; original coefficient algebra and symbolic T; 1-z^6 invertible','X_z=(1-z^6)^(-1) sum z^j U^j B; formal surreal coefficient return; exact spectral sensor',['BG-BRAID'])]
rows=[]
for id,start,end,h,c,parents in sections:
    body=s.split('\\section{'+start+'}',1)[1].split('\\section{'+end+'}',1)[0].strip()
    r={'id':id,'source':'Braided_Gauge_H24/paper.tex: '+start,'hypotheses':h,'conclusion':c,'parents':parents,'proof_source':body}
    w=old['quote'](r);a=old['anchor'](w);g=(1<<len(w))-1+a
    assert old['unquote'](old['decode_address'](g))==r
    codes={}
    for name,spec in old['SPECS'].items():
        words=old['blocks'](g,spec);ret=old['readblocks'](words,spec,old['tabs'][name]);assert ret==g
        assert old['unquote'](old['decode_address'](ret))==r
        codes[name]=[''.join(map(str,w)) for w in words]
    rows.append({**r,'depth':len(w),'godel_hex':hex(g),'residue':hex(a),'four_golay':codes,'quote_sha256':hashlib.sha256(w.encode()).hexdigest()})
(P/'gauge_port_codes.json').write_text(json.dumps(rows,indent=2)+'\n')
print('new written theorem ports',len(rows),'full source Golay readbacks',4*len(rows))
