"""Exact gauge identities from the original null-cone chart (4.21).
The fields here are smooth classical coordinate functions; the separate
quantum ordered square is preserved in the previous paper.
"""
import sympy as S
from pathlib import Path
import json
p,y=S.symbols('p y',positive=True,real=True)
# p=exp(z1), y=z2; d/dz1=p d/dp.
e=S.Matrix([[S.sqrt(p),S.sqrt(p)*y],[0,1/S.sqrt(p)]])
q=e.T*e
D=lambda a:p*a.diff(p)
Jx=S.simplify(D(e)*e.inv()); Jy=S.simplify(e.diff(y)*e.inv())
Px=(Jx+Jx.T)/2; Py=(Jy+Jy.T)/2
Ox=(Jx-Jx.T)/2; Oy=(Jy-Jy.T)/2
Ax=-Ox; Ay=-Oy
comm=lambda a,b:a*b-b*a
zero=S.zeros(2)
checks={}
def ck(n,a,b):
    assert S.simplify(a-b)==(zero if isinstance(a,S.MatrixBase) else 0),(n,a,b)
    checks[n]='exact symbolic identity'
ck('original_metric',q,S.Matrix([[p,p*y],[p*y,1/p+p*y*y]]))
ck('determinant',q.det(),1)
ck('right_Maurer_Cartan',D(Jy)-Jx.diff(y)-comm(Jx,Jy),zero)
ck('Cartan_curvature',D(Ay)-Ax.diff(y)+comm(Ax,Ay),-comm(Px,Py))
ck('covariant_torsion',D(Py)-Px.diff(y)+comm(Ax,Py)-comm(Ay,Px),zero)
ck('g_xx',2*S.trace(Px*Px),1)
ck('g_yy',2*S.trace(Py*Py),p*p)
ck('g_xy',2*S.trace(Px*Py),0)
ck('nonflat_connection',D(Ay)-Ax.diff(y)+comm(Ax,Ay),S.Matrix([[0,-p/2],[p/2,0]]))
a,b=S.symbols('a b',real=True); J=a*Jx+b*Jy; Qdot=a*D(q)+b*q.diff(y)
ck('invariant_shear',S.trace(q.inv()*Qdot*q.inv()*Qdot)/2,a*a+p*p*b*b)
# Gauge covariance of curvature is algebraic and follows from D'=gDg^-1.
# Check the free associative Jacobi identity without substituting a matrix size.
x,z,t=S.symbols('x z t',commutative=False)
ck('covariant_Jacobi',S.expand(comm(x,comm(z,t))+comm(z,comm(t,x))+comm(t,comm(x,z))),0)
Path(__file__).with_name('gauge_exact_receipt.json').write_text(json.dumps(checks,indent=2)+'\n')
print('exact symbolic gauge identities',len(checks))
