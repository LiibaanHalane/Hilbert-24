import Mathlib

/- Algebraic ports of the written braided gauge continuation. No new axioms. -/
namespace BraidedGauge
variable {G : Type*} [Group G]

theorem hurwitz_product (a b : G) : b * (b⁻¹ * a * b) = a * b := by group

theorem hurwitz_inverse (a b : G) : b * (b⁻¹ * a * b) * b⁻¹ = a := by group

theorem holonomy_correction (h T : G) : T * (T⁻¹ * h * T) * T⁻¹ = h := by group

theorem flat_cycle (h T : G) (hflat : h * T = 1) : T⁻¹ * h * T = h := by
  rw [mul_assoc, hflat, mul_one]
  calc
    T⁻¹ = (h * T) * T⁻¹ := by rw [hflat, one_mul]
    _ = h := by group

variable {R : Type*} [Ring R]
theorem jacobi (x y z : R) :
    x*(y*z-z*y)-(y*z-z*y)*x +
    y*(z*x-x*z)-(z*x-x*z)*y +
    z*(x*y-y*x)-(x*y-y*x)*z = 0 := by noncomm_ring

-- These are finite algebraic consequences only. The boundary minimization
-- and unbounded operator domains are in the written proof.
end BraidedGauge
