#!/usr/bin/env python3
"""Glue original source constructors; no new physical solver or substituted Hamiltonian."""
from pathlib import Path
import sys, json, hashlib, runpy, math
from fractions import Fraction as F
from dataclasses import dataclass
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'original'/'canonical'))
from canonical import Ball
sys.path.insert(0,str(P/'original'/'signed'))
from native_polynomial import Poly, T, ONE, ZERO
from native_coefficients import E
import signed_fold as H24

# Exact original prefix monoid. Padding is tagged, not a new inference.
@dataclass(frozen=True)
class Prefix:
    L:int; drift:int; low:int
    def then(self,b): return Prefix(self.L+b.L,self.drift+b.drift,min(self.low,self.drift+b.low))
EMPTY=Prefix(0,0,0)
def summary(w):
    a=EMPTY
    for b in w:a=a.then(Prefix(1,2 if b=='0' else -1,0 if b=='0' else -1))
    return a

def ternary(t):
    c=t['children']
    if not c:return '1',{'rule':t['rule'],'judgment':t['judgment'],'arity':0,'source':t['source'],'physical_mark':t['physical_mark'],'relative_grade':t['cost']}
    assert len(c)<=3
    xs=[ternary(x) for x in c]; w='0'+''.join(x[0] for x in xs)+'1'*(3-len(c))
    mark={'rule':t['rule'],'judgment':t['judgment'],'arity':len(c),'source':t['source'],'physical_mark':t['physical_mark'],'relative_grade':t['cost'],'children':[x[1] for x in xs]}
    return w,mark

def from_tree(w,mark,i=0):
    k=mark['arity']; assert w[i]==('0' if k else '1'); i+=1
    cs=[]
    if k:
        for c in mark['children']:
            t,i=from_tree(w,c,i);cs.append(t)
        assert w[i:i+3-k]=='1'*(3-k);i+=3-k
    return {'rule':mark['rule'],'judgment':mark['judgment'],'source':mark['source'],'physical_mark':mark['physical_mark'],'cost':mark['relative_grade'],'children':cs},i

# Original six-strand dagger braid and guarded convolution, implemented on the
# unchanged native coefficient/physical-polynomial chart. This is an adapter
# of the archived formula, not a claim to have executed canonical_torser.py.
def U(x):return tuple(x[(i-1)%6].dagger() for i in range(6))
def theta(x):return tuple(reversed(tuple(a.dagger() if i%2 else a for i,a in enumerate(x))))
def theta_inv(x):return tuple(a.dagger() if i%2 else a for i,a in enumerate(reversed(x)))
def rot(x):return x[1:]+x[:1]
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def scale(a,r):return tuple(x.scale(r) for x in a)
def braid_pow(x,n):
    for _ in range(n%6):x=U(x)
    return x

def fixed(B,z):
    acc=(ZERO,)*6
    for j in range(6):acc=add(acc,scale(braid_pow(B,j),z**j))
    return scale(acc,1/(1-z**6))

# Exact old source polynomial in the same original heat operator.
q=F(2,3); B=(ONE,T,T*T,ONE-T,ONE.scale(q)-T,(ONE-T)*(ONE.scale(q)-T))
assert B[-1].scale(3)==ONE.scale(2)-T.scale(5)+(T*T).scale(3)
assert theta_inv(theta(B))==B and U(theta(B))==theta(rot(B))
for z in (F(2),F(2,3)):
    X=fixed(B,z); assert add(B,scale(U(X),z))==X
    Y=X
    for _ in range(6):Y=U(Y)
    assert Y==X
X=fixed(B,q)
# A noncommuting finite native control: exact group generators, not a physical H.
e=E.make((1,0,1,0,0,1)); r=E.make((1,0,0,-1,1,-1)); s=E.make((1,1,1,-1,0,-1))
assert r*r*r==e and s*s==e and s*r*s==r.dagger()
def mul(xs):
    a=e
    for x in xs:a=a*x
    return a
def hurwitz(h):
    t=mul(h[1:]); return h[1:]+(t.dagger()*h[0]*t,)
def correct(h):
    t=mul(h[:-1]);return h[:-1]+(t*h[-1]*t.dagger(),)
h=(r,s,r*s,s,r,r); h0=h[:-1]+(mul(h[:-1]).dagger(),)
assert mul(h)!=e and mul(h0)==e
assert correct(hurwitz(h))==rot(h) and hurwitz(h0)==rot(h0)
assert mul(hurwitz(h))==mul(h)
assert theta_inv(theta(h))==h and U(theta(h))==theta(rot(h))
assert U(theta(h))==theta(correct(hurwitz(h)))
# Surreal series is formal operator-valued Hahn support, not a dyadic-to-real embedding.
# A coefficient query at arbitrary n is a direct reduction to one of the six terms.
n=10**100+5; assert braid_pow(B,n)==braid_pow(B,n%6)
check=B
for _ in range(6): check=U(check)
assert check==B

# Source proof families: these are conditional terms built by the actual original fold.
leaves=['stokes_square+','schur_blocks+','heat_cap+','dyadic_cap+','green_cap+','parametrix+']
strands=[]
for i,k in enumerate(leaves):
    f=H24.results['schema:'+k]; t=f['targets']['original_YM+']; assert t is not None
    w,mark=ternary(t); s0=summary(w)
    assert s0.low==s0.drift==-1 and all(summary(w[:j]).low==0 for j in range(len(w)))
    back,j=from_tree(w,mark);assert j==len(w) and back==t
    ball=Ball.from_word(w);assert ball.word()==w
    for j in range(len(w)+1):
        child=Ball.from_word(w[:j]);assert ball.a%(1<<j)==child.a
    strands.append({'strand':i,'supplier':k,'hypotheses':f['leaf_evidence'],'original_term':t,'tree_marks':mark,'prefix_word':w,'summary':s0.__dict__,'canonical_ball':ball.record(),'operator_seed':B[i].encoded(),'fixed_point_coefficients':X[i].encoded(),'surreal_support':'sum_{n>=0} omega^(-n) [U^n B]_i; coefficient query n mod 6','relative_meaning':'unit rule occurrence grade; not physical time or bit work'})

# Shared complete Antihydra grammar R_k=0 R_{k-1}^3, R_0=1.
# The low-first 64-bit observation need not materialize R_64.
levels=[Prefix(1,-1,-1)]
for k in range(1,65):
    a=Prefix(1,2,0);b=levels[-1]
    for _ in range(3):a=a.then(b)
    levels.append(a)
assert levels[-1]==Prefix((3**65-1)//2,-1,-1)
def first_hit(k,balance):
    if balance+levels[k].low>=0:return None
    if k==0:return 1
    offset=1;balance+=2
    for _ in range(3):
        j=first_hit(k-1,balance)
        if j is not None:return offset+j
        offset+=levels[k-1].L;balance+=levels[k-1].drift
    raise AssertionError('missing first failure')
assert first_hit(64,0)==levels[-1].L
# Braid the actual marked source packets alongside the coefficient operators.
# A dagger toggles orientation of the retained view, NOT truth of the source.
pack=tuple((row,B[i],False) for i,row in enumerate(strands))
def packet_braid(p):
    return tuple((p[(i-1)%6][0],p[(i-1)%6][1].dagger(),not p[(i-1)%6][2]) for i in range(6))
v=pack
for j in range(1,7):
    v=packet_braid(v)
    assert tuple(x[1] for x in v)==braid_pow(B,j)
assert v==pack
# Original 4-Golay checker and code functions; use them on the actual new strand balls.
old=runpy.run_path(str(P/'original'/'nullcone'/'check.py'))
for row in strands:
    g=int(row['canonical_ball']['g'],16); codes={}
    for name,spec in old['SPECS'].items():
        words=old['blocks'](g,spec); ret=old['readblocks'](words,spec,old['tabs'][name]); assert ret==g
        assert Ball(ret).word()==row['prefix_word'];codes[name]=[''.join(map(str,w)) for w in words]
    row['four_golay']=codes
    # Preserve the entire source term in a separate length-prefixed original
    # theorem-port quotation; no bare prefix shape identifies the theorem.
    def pretty(t):
        return (t['rule']+' : '+t['judgment']+' | '+t['physical_mark']+' | '+str(t['cost'])+' | '+t['source']+'\n'
                +'[\n'+''.join(pretty(x) for x in t['children'])+']\n')
    r={'id':'BRAID-'+str(row['strand']),'source':'YM_Signed_H24_Clopen_Descent/signed_fold.py',
       'hypotheses':'\n'.join(k+' = '+v for k,v in sorted(row['hypotheses'].items())),
       'conclusion':'Conditional original_YM+ in the fixed original source context','parents':[],
       'proof_source':pretty(row['original_term'])}
    w=old['quote'](r);a=old['anchor'](w);g=(1<<len(w))-1+a
    assert old['unquote'](old['decode_address'](g))==r
    full={}
    for name,spec in old['SPECS'].items():
        words=old['blocks'](g,spec);ret=old['readblocks'](words,spec,old['tabs'][name]);assert ret==g
        assert old['unquote'](old['decode_address'](ret))==r
        full[name]=[''.join(map(str,b)) for b in words]
    row['full_source_quote']=r;row['full_source_ball']={'depth':len(w),'residue':hex(a),'g':hex(g)};row['full_source_four_golay']=full

# Attach gauge/null-cone rules to the existing min-plus engine (no solver rewrite).
# The physical fields are hypotheses; the new Cartan and boundary result are theorem ports.
H24.R.extend([
 H24.Rule('BGCartan','cartan+',('metric+',),'paper: exact frame and Maurer-Cartan return'),
 H24.Rule('BGFocusing','relative_focusing+',('cartan+',),'paper: Xi = half integral weighted trace P^2'),
 H24.Rule('BGBoundaryMinimum','boundary_min+',('relative_focusing+','boundary_data+'),'paper: hyperbolic geodesic and weighted Cauchy Schwarz'),
 H24.Rule('BGClockState','diamond_state+',('closed_forms+','positive_resolvent+'),'prior NullCone paper: uniform positive resolvent return')])
H24.J=sorted({r.head for r in H24.R}|{x for r in H24.R for x in r.tail})
ctx={'metric+':'HYP: smooth det-one transverse metric in paper eq 4.21a','boundary_data+':'HYP: two fixed endpoint metrics, 0<epsilon<v','closed_forms+':'HYP: same original monotone closed forms','positive_resolvent+':'HYP: original uniform positive resolvent reserve'}
f=H24.fold('null-cone:fixed-boundary:marked-source',ctx)
assert f['potential']['boundary_min+']==3 and f['potential']['diamond_state+']==1
assert f['targets']['original_YM+'] is None
# Reconstruct actual new term from original engine tight production registry.
by={r.name:r for r in H24.R}
def term(j):
    if j in ctx:return {'judgment':j,'hypothesis':ctx[j],'relative_grade':0}
    k=f['tight_productions'][j][0];r=by[k]
    return {'judgment':j,'rule':k,'source':r.source,'relative_grade':f['potential'][j],'children':[term(x) for x in r.tail]}
newterms={j:term(j) for j in ('boundary_min+','diamond_state+')}
(P/'braided_strands.json').write_text(json.dumps(strands,indent=2)+'\n')
(P/'gauge_terms.json').write_text(json.dumps(newterms,indent=2)+'\n')
rec={'original_signed_fold':{'rules':28,'judgments':32,'conditional_routes':13},'six_actual_conditional_strand_terms':len(strands),'prefix_roundtrips':6,'four_Golay_prefix_roundtrips':24,'four_Golay_full_source_roundtrips':24,'shared_Antihydra_depth64_length':str(levels[-1].L),'shared_Antihydra_first_failure':str(first_hit(64,0)),'marked_packet_braid_return':True,'fixed_point_guards':['2','2/3'],'flat_and_nonflat_native_Hurwitz':True,'surreal_coefficient_query':str(n),'new_rules':4,'new_relative_minimum_grades':{k:v['relative_grade'] for k,v in newterms.items()},'original_YM_endpoint':None,'note':'Original signed_fold.py, native_polynomial.py, native_coefficients.py and canonical.py executed. New source wiring implements recovered braid equation using their coefficient operations; no kernel check or complete physical Hamiltonian supplied.'}
(P/'braided_receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2))
